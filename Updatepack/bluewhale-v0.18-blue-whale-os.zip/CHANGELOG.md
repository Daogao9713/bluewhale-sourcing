# Blue Whale V0.18 Changelog

## Release type

Even version: frontend / workspace UX / information architecture.

## Blue Whale OS

V0.18 redesigns `/workspace` as the internal operating console for Blue Whale New Energy.

### Navigation

Persistent sidebar:

- Dashboard
- Company News
- Projects
- Suppliers
- RFQ
- Inquiries
- AI Copilot

Company News is now a first-class navigation item. No manual `/workspace/news` URL entry is needed.

### Dashboard

New operational dashboard includes:

- project count
- supplier count
- RFQ count
- inquiry count
- recent project / inquiry activity
- quick access to Company News
- quick access to public website
- system-layer overview

### Operational modules

Projects, Suppliers, RFQ and Inquiries share a consistent table-first UI.

V0.18 keeps the V0.1 workspace API contract instead of changing the database schema again.

### AI

Internal AI Copilot is presented as a dedicated OS module.

The public website AI Concierge remains separate.

### Visual system

- dark persistent sidebar
- white operational surfaces
- cyan system accents
- larger information hierarchy
- responsive mobile navigation
- less procurement-landing-page styling
- more operating-system / industrial SaaS styling

## Preserved

- V0.17 CMS architecture and RLS model
- V0.16 multilingual public website
- Company News CMS
- public News pages and ticker
- public AI Concierge
- existing Supabase tables from V0.1
- existing inquiry flow
