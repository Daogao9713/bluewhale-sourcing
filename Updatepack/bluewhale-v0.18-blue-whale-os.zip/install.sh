#!/usr/bin/env bash
set -euo pipefail
TARGET="${1:-}"
if [[ -z "$TARGET" ]]; then
  echo "Usage: ./install.sh /path/to/bluewhale-sourcing"
  exit 1
fi
if [[ ! -d "$TARGET" ]]; then
  echo "Target directory does not exist: $TARGET"
  exit 1
fi
SOURCE="$(cd "$(dirname "$0")" && pwd)"
FILES=(
  "app/workspace/page.tsx"
  "components/WorkspaceShell.tsx"
  "components/NewsAdmin.tsx"
  "CHANGELOG.md"
  "INSTALL.md"
  "VERSIONING.md"
)
for file in "${FILES[@]}"; do
  mkdir -p "$(dirname "$TARGET/$file")"
  cp "$SOURCE/$file" "$TARGET/$file"
  echo "Installed $file"
done
echo
echo "Blue Whale V0.18 Blue Whale OS installed."
echo "No new database migration is required."
