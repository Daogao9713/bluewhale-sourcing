# Blue Whale V0.18 · Blue Whale OS

Install on top of V0.17.

V0.18 is a frontend / workspace information-architecture release. It deliberately reuses the database tables and APIs established by V0.1 and the CMS/security work from V0.17.

## Install

Create a branch:

```bash
git checkout -b frontend/v0.18-blue-whale-os
```

Windows:

```powershell
.\install.ps1 "C:\path\to\bluewhale-sourcing"
```

macOS / Linux:

```bash
chmod +x install.sh
./install.sh /path/to/bluewhale-sourcing
```

Then:

```bash
npm install
npm run build
npm run dev
```

## Database

V0.18 does not introduce a new required database migration.

Keep the V0.1 sourcing tables that fixed `/api/workspace`.

Keep the V0.17 CMS migration for Company News.

## Test

Open `/workspace`.

Expected sidebar:

- Dashboard
- Company News
- Projects
- Suppliers
- RFQ
- Inquiries
- AI Copilot

Click **Company News**. It should route to `/workspace/news`.

From the CMS, click **Blue Whale OS** to return.

Confirm Dashboard loads data from `/api/workspace`.

Confirm Projects / Suppliers / RFQ / Inquiries render without manually changing URLs.

Confirm mobile width shows the Menu button.

## Important

V0.18 does not remove or disable Supabase RLS.

V0.18 does not expose `SUPABASE_SERVICE_ROLE_KEY` to the browser.

V0.18 does not replace the public website.

It reorganizes the internal workspace only.
