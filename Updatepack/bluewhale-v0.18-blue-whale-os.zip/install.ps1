param([Parameter(Mandatory=$true)][string]$Target)
$ErrorActionPreference = "Stop"
if (-not (Test-Path $Target)) { throw "Target directory does not exist: $Target" }
$Source = Split-Path -Parent $MyInvocation.MyCommand.Path
$Files = @(
  "app/workspace/page.tsx",
  "components/WorkspaceShell.tsx",
  "components/NewsAdmin.tsx",
  "CHANGELOG.md",
  "INSTALL.md",
  "VERSIONING.md"
)
foreach ($File in $Files) {
  $From = Join-Path $Source $File
  $To = Join-Path $Target $File
  $Dir = Split-Path -Parent $To
  if (-not (Test-Path $Dir)) { New-Item -ItemType Directory -Force -Path $Dir | Out-Null }
  Copy-Item -Force $From $To
  Write-Host "Installed $File"
}
Write-Host ""
Write-Host "Blue Whale V0.18 Blue Whale OS installed."
Write-Host "No new database migration is required."
