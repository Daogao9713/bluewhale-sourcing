#!/usr/bin/env bash
set -euo pipefail

TARGET="${1:-}"

if [[ -z "$TARGET" ]]; then
  echo "Usage: ./install.sh /path/to/bluewhale-sourcing"
  exit 1
fi

if [[ ! -d "$TARGET" ]]; then
  echo "Target directory does not exist: $TARGET"
  exit 1
fi

SOURCE="$(cd "$(dirname "$0")" && pwd)"

FILES=(
  "lib/workspace-auth.ts"
  "app/workspace/page.tsx"
  "app/api/workspace/route.ts"
  "app/api/agent/route.ts"
  "components/WorkspaceShell.tsx"
  "supabase/bluewhale_v01.sql"
  ".env.example.additions"
  "INSTALL.md"
)

for file in "${FILES[@]}"; do
  mkdir -p "$(dirname "$TARGET/$file")"
  cp "$SOURCE/$file" "$TARGET/$file"
  echo "Installed $file"
done

echo
echo "Blue Whale Sourcing OS V0.1 overlay installed."
echo "Next: run supabase/bluewhale_v01.sql and configure environment variables."
