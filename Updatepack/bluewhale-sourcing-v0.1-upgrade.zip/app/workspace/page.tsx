import type { Metadata } from "next";
import WorkspaceShell from "@/components/WorkspaceShell";

export const metadata: Metadata = {
  title: "Sourcing OS | Blue Whale",
  description: "Internal sourcing workspace for projects, suppliers, RFQs and AI analysis.",
};

export default function WorkspacePage() {
  return <WorkspaceShell />;
}
