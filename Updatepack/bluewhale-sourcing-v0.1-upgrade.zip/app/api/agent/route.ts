import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase";
import { verifyWorkspaceKey } from "@/lib/workspace-auth";

type AgentMessage = {
  role: "user" | "assistant";
  content: string;
};

function extractOutputText(response: any) {
  if (typeof response?.output_text === "string") {
    return response.output_text;
  }

  const chunks: string[] = [];

  for (const item of response?.output || []) {
    for (const content of item?.content || []) {
      if (
        (content?.type === "output_text" || content?.type === "text") &&
        typeof content?.text === "string"
      ) {
        chunks.push(content.text);
      }
    }
  }

  return chunks.join("\n").trim();
}

function compact(value: unknown, limit = 12000) {
  const text = JSON.stringify(value ?? [], null, 2);
  return text.length > limit ? `${text.slice(0, limit)}\n...[truncated]` : text;
}

export async function POST(req: Request) {
  const auth = verifyWorkspaceKey(req);

  if (!auth.ok) {
    return NextResponse.json(
      { success: false, error: auth.error },
      { status: auth.status }
    );
  }

  try {
    const body = await req.json();
    const message = String(body?.message || "").trim();
    const history = (Array.isArray(body?.history) ? body.history : [])
      .filter(
        (item: AgentMessage) =>
          (item?.role === "user" || item?.role === "assistant") &&
          typeof item?.content === "string"
      )
      .slice(-8);

    if (!message) {
      return NextResponse.json(
        { success: false, error: "Message is required." },
        { status: 400 }
      );
    }

    const openaiKey = process.env.OPENAI_API_KEY;

    if (!openaiKey) {
      return NextResponse.json(
        {
          success: false,
          error: "OPENAI_API_KEY is not configured.",
        },
        { status: 503 }
      );
    }

    const [projects, suppliers, rfqs, inquiries] = await Promise.all([
      supabaseAdmin
        .from("projects")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(40),
      supabaseAdmin
        .from("suppliers")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(60),
      supabaseAdmin
        .from("rfqs")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(60),
      supabaseAdmin
        .from("inquiries")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(30),
    ]);

    const dbError =
      projects.error || suppliers.error || rfqs.error || inquiries.error;

    if (dbError) {
      console.error("[agent:db]", dbError);
      return NextResponse.json(
        { success: false, error: "Could not load sourcing data." },
        { status: 500 }
      );
    }

    const businessContext = `
PROJECTS:
${compact(projects.data, 9000)}

SUPPLIERS:
${compact(suppliers.data, 12000)}

RFQS:
${compact(rfqs.data, 10000)}

RECENT INQUIRIES:
${compact(inquiries.data, 7000)}
`;

    const input = [
      {
        role: "system",
        content: `
You are Blue Whale Sourcing Copilot, an internal procurement analyst for a China-focused global sourcing business.

Your job is to help the operator:
- understand incoming sourcing requests,
- compare projects, suppliers and RFQs,
- identify missing specifications,
- identify commercial and supply-chain risks,
- recommend concrete next actions,
- draft RFQ structures and supplier comparison criteria.

Rules:
1. Treat the supplied database context as the only source of truth for internal records.
2. Never invent a supplier, quote, certification, lead time or price that is not in the context.
3. Clearly distinguish facts from recommendations.
4. If data is missing, say exactly what is missing.
5. Prefer concise business analysis with actionable next steps.
6. Do not expose secrets, environment variables, internal keys or implementation details.
7. Reply in the language used by the operator unless asked otherwise.

CURRENT DATABASE CONTEXT:
${businessContext}
        `.trim(),
      },
      ...history.map((item: AgentMessage) => ({
        role: item.role,
        content: item.content.slice(0, 2500),
      })),
      {
        role: "user",
        content: message.slice(0, 5000),
      },
    ];

    const model = process.env.OPENAI_MODEL || "gpt-5.6-luna";

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${openaiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model,
        input,
        reasoning: { effort: "low" },
        max_output_tokens: 1400,
      }),
    });

    const result = await response.json();

    if (!response.ok) {
      console.error("[agent:openai]", result);
      return NextResponse.json(
        { success: false, error: "AI request failed." },
        { status: 502 }
      );
    }

    const reply = extractOutputText(result);

    return NextResponse.json({
      success: true,
      reply: reply || "No response generated.",
      model,
    });
  } catch (error) {
    console.error("[agent]", error);
    return NextResponse.json(
      { success: false, error: "Server error." },
      { status: 500 }
    );
  }
}
