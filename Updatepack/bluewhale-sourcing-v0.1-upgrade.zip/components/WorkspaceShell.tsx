"use client";

import Link from "next/link";
import { FormEvent, ReactNode, useEffect, useMemo, useState } from "react";

type Project = {
  id: string;
  name: string;
  client_name?: string | null;
  country?: string | null;
  category?: string | null;
  target_budget?: number | null;
  currency?: string | null;
  status?: string | null;
  notes?: string | null;
  created_at?: string;
};

type Supplier = {
  id: string;
  company_name: string;
  country?: string | null;
  categories?: string[] | null;
  contact_name?: string | null;
  email?: string | null;
  rating?: number | null;
  risk_level?: string | null;
  notes?: string | null;
  created_at?: string;
};

type Rfq = {
  id: string;
  project_id?: string | null;
  title: string;
  specification?: string | null;
  quantity?: string | null;
  target_price?: number | null;
  currency?: string | null;
  status?: string | null;
  due_date?: string | null;
  created_at?: string;
};

type Inquiry = {
  id: string;
  company_name?: string | null;
  contact_name?: string | null;
  email?: string | null;
  country?: string | null;
  product_name?: string | null;
  model_number?: string | null;
  quantity?: string | null;
  message?: string | null;
  created_at?: string;
};

type WorkspaceData = {
  projects: Project[];
  suppliers: Supplier[];
  rfqs: Rfq[];
  inquiries: Inquiry[];
};

type AgentMessage = {
  role: "user" | "assistant";
  content: string;
};

const emptyData: WorkspaceData = {
  projects: [],
  suppliers: [],
  rfqs: [],
  inquiries: [],
};

const tabs = [
  { id: "overview", label: "Overview" },
  { id: "projects", label: "Projects" },
  { id: "suppliers", label: "Suppliers" },
  { id: "rfqs", label: "RFQ" },
  { id: "inquiries", label: "Inquiries" },
  { id: "agent", label: "AI Copilot" },
] as const;

type TabId = (typeof tabs)[number]["id"];

function formatMoney(value?: number | null, currency?: string | null) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) {
    return "—";
  }

  try {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: currency || "USD",
      maximumFractionDigits: 0,
    }).format(Number(value));
  } catch {
    return `${currency || "USD"} ${value}`;
  }
}

function formatDate(value?: string | null) {
  if (!value) return "—";

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;

  return new Intl.DateTimeFormat("en-CA", {
    year: "numeric",
    month: "short",
    day: "2-digit",
  }).format(date);
}

function statusTone(status?: string | null) {
  const value = (status || "").toLowerCase();

  if (["active", "sent", "quoted", "won", "approved"].includes(value)) {
    return "bg-emerald-50 text-emerald-700 ring-emerald-200";
  }

  if (["blocked", "lost", "high"].includes(value)) {
    return "bg-rose-50 text-rose-700 ring-rose-200";
  }

  if (["waiting", "pending", "medium"].includes(value)) {
    return "bg-amber-50 text-amber-700 ring-amber-200";
  }

  return "bg-slate-100 text-slate-600 ring-slate-200";
}

function Badge({ children, value }: { children: ReactNode; value?: string | null }) {
  return (
    <span
      className={`inline-flex rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset ${statusTone(
        value
      )}`}
    >
      {children}
    </span>
  );
}

function Metric({
  label,
  value,
  note,
}: {
  label: string;
  value: string | number;
  note: string;
}) {
  return (
    <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
      <p className="text-sm font-medium text-slate-500">{label}</p>
      <p className="mt-3 text-3xl font-semibold tracking-tight text-slate-950">
        {value}
      </p>
      <p className="mt-2 text-xs text-slate-500">{note}</p>
    </div>
  );
}

function Empty({ children }: { children: ReactNode }) {
  return (
    <div className="rounded-3xl border border-dashed border-slate-300 bg-white p-10 text-center text-sm text-slate-500">
      {children}
    </div>
  );
}

export default function WorkspaceShell() {
  const [adminKey, setAdminKey] = useState("");
  const [draftKey, setDraftKey] = useState("");
  const [data, setData] = useState<WorkspaceData>(emptyData);
  const [activeTab, setActiveTab] = useState<TabId>("overview");
  const [loading, setLoading] = useState(false);
  const [mutationLoading, setMutationLoading] = useState(false);
  const [error, setError] = useState("");
  const [agentInput, setAgentInput] = useState("");
  const [agentMessages, setAgentMessages] = useState<AgentMessage[]>([]);
  const [agentLoading, setAgentLoading] = useState(false);

  useEffect(() => {
    const stored = window.sessionStorage.getItem("bluewhale_admin_key") || "";
    if (stored) {
      setAdminKey(stored);
    }
  }, []);

  useEffect(() => {
    if (adminKey) {
      loadWorkspace(adminKey);
    }
  }, [adminKey]);

  async function loadWorkspace(key = adminKey) {
    if (!key) return;

    setLoading(true);
    setError("");

    try {
      const res = await fetch("/api/workspace", {
        headers: { "x-admin-key": key },
        cache: "no-store",
      });

      const payload = await res.json();

      if (!res.ok) {
        throw new Error(payload?.error || "Failed to load workspace.");
      }

      setData({
        projects: payload.projects || [],
        suppliers: payload.suppliers || [],
        rfqs: payload.rfqs || [],
        inquiries: payload.inquiries || [],
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load workspace.");
      if ((err as Error)?.message === "Unauthorized") {
        window.sessionStorage.removeItem("bluewhale_admin_key");
        setAdminKey("");
      }
    } finally {
      setLoading(false);
    }
  }

  function unlock(e: FormEvent) {
    e.preventDefault();
    const key = draftKey.trim();
    if (!key) return;
    window.sessionStorage.setItem("bluewhale_admin_key", key);
    setAdminKey(key);
  }

  function lockWorkspace() {
    window.sessionStorage.removeItem("bluewhale_admin_key");
    setAdminKey("");
    setDraftKey("");
    setData(emptyData);
    setAgentMessages([]);
  }

  async function createEntity(
    entity: "project" | "supplier" | "rfq",
    payload: Record<string, unknown>
  ) {
    setMutationLoading(true);
    setError("");

    try {
      const res = await fetch("/api/workspace", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-admin-key": adminKey,
        },
        body: JSON.stringify({ entity, data: payload }),
      });

      const result = await res.json();

      if (!res.ok) {
        throw new Error(result?.error || "Create failed.");
      }

      await loadWorkspace();
      return true;
    } catch (err) {
      setError(err instanceof Error ? err.message : "Create failed.");
      return false;
    } finally {
      setMutationLoading(false);
    }
  }

  async function submitProject(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const fd = new FormData(form);

    const ok = await createEntity("project", {
      name: fd.get("name"),
      client_name: fd.get("client_name"),
      country: fd.get("country"),
      category: fd.get("category"),
      target_budget: fd.get("target_budget")
        ? Number(fd.get("target_budget"))
        : null,
      currency: fd.get("currency") || "USD",
      status: fd.get("status") || "active",
      notes: fd.get("notes"),
    });

    if (ok) form.reset();
  }

  async function submitSupplier(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const fd = new FormData(form);

    const categories = String(fd.get("categories") || "")
      .split(",")
      .map((item) => item.trim())
      .filter(Boolean);

    const ok = await createEntity("supplier", {
      company_name: fd.get("company_name"),
      country: fd.get("country"),
      categories,
      contact_name: fd.get("contact_name"),
      email: fd.get("email"),
      phone: fd.get("phone"),
      rating: fd.get("rating") ? Number(fd.get("rating")) : null,
      risk_level: fd.get("risk_level") || "unknown",
      notes: fd.get("notes"),
    });

    if (ok) form.reset();
  }

  async function submitRfq(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const fd = new FormData(form);

    const ok = await createEntity("rfq", {
      project_id: fd.get("project_id") || null,
      title: fd.get("title"),
      specification: fd.get("specification"),
      quantity: fd.get("quantity"),
      target_price: fd.get("target_price")
        ? Number(fd.get("target_price"))
        : null,
      currency: fd.get("currency") || "USD",
      status: fd.get("status") || "draft",
      due_date: fd.get("due_date") || null,
    });

    if (ok) form.reset();
  }

  async function askAgent(e: FormEvent) {
    e.preventDefault();
    const message = agentInput.trim();

    if (!message || agentLoading) return;

    const nextHistory: AgentMessage[] = [
      ...agentMessages,
      { role: "user", content: message },
    ];

    setAgentMessages(nextHistory);
    setAgentInput("");
    setAgentLoading(true);
    setError("");

    try {
      const res = await fetch("/api/agent", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-admin-key": adminKey,
        },
        body: JSON.stringify({
          message,
          history: agentMessages.slice(-8),
        }),
      });

      const result = await res.json();

      if (!res.ok) {
        throw new Error(result?.error || "AI request failed.");
      }

      setAgentMessages([
        ...nextHistory,
        {
          role: "assistant",
          content: result.reply || "No response generated.",
        },
      ]);
    } catch (err) {
      setError(err instanceof Error ? err.message : "AI request failed.");
    } finally {
      setAgentLoading(false);
    }
  }

  const activeProjects = useMemo(
    () =>
      data.projects.filter(
        (project) =>
          !["won", "lost", "closed"].includes((project.status || "").toLowerCase())
      ).length,
    [data.projects]
  );

  const highRiskSuppliers = useMemo(
    () =>
      data.suppliers.filter(
        (supplier) => (supplier.risk_level || "").toLowerCase() === "high"
      ).length,
    [data.suppliers]
  );

  const projectNameById = useMemo(
    () =>
      Object.fromEntries(
        data.projects.map((project) => [project.id, project.name])
      ) as Record<string, string>,
    [data.projects]
  );

  if (!adminKey) {
    return (
      <main className="min-h-screen bg-[radial-gradient(circle_at_top_right,#cffafe,transparent_32%),#f8fafc] px-6 py-14">
        <div className="mx-auto max-w-md">
          <Link
            href="/"
            className="text-sm font-medium text-slate-500 transition hover:text-slate-950"
          >
            ← Blue Whale Sourcing
          </Link>

          <div className="mt-16 rounded-[2rem] border border-white bg-white/90 p-8 shadow-2xl shadow-cyan-950/10 backdrop-blur">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-950 text-lg font-semibold text-white">
              BW
            </div>

            <p className="mt-8 text-xs font-semibold uppercase tracking-[0.2em] text-cyan-700">
              Internal Workspace
            </p>
            <h1 className="mt-3 text-3xl font-semibold tracking-tight text-slate-950">
              Sourcing OS
            </h1>
            <p className="mt-3 text-sm leading-6 text-slate-600">
              Projects, suppliers, RFQs and AI analysis in one operating surface.
            </p>

            <form onSubmit={unlock} className="mt-8">
              <label className="text-sm font-medium text-slate-700">
                Workspace access key
              </label>
              <input
                value={draftKey}
                onChange={(e) => setDraftKey(e.target.value)}
                type="password"
                autoComplete="current-password"
                placeholder="BLUEWHALE_ADMIN_KEY"
                className="mt-2 w-full rounded-2xl border border-slate-300 bg-white px-4 py-3 text-slate-950 outline-none transition focus:border-cyan-600 focus:ring-4 focus:ring-cyan-100"
              />
              <button className="mt-4 w-full rounded-2xl bg-slate-950 px-5 py-3 font-medium text-white transition hover:bg-cyan-700">
                Unlock workspace
              </button>
            </form>

            {error ? (
              <p className="mt-4 text-sm text-rose-600">{error}</p>
            ) : null}
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-slate-50 text-slate-950">
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/90 backdrop-blur">
        <div className="mx-auto flex max-w-[1500px] items-center justify-between px-5 py-4 lg:px-8">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-slate-950 text-sm font-semibold text-white">
              BW
            </div>
            <div>
              <p className="font-semibold tracking-tight">Blue Whale Sourcing OS</p>
              <p className="text-xs text-slate-500">Procurement workspace · V0.1</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Link
              href="/"
              className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-600 transition hover:border-slate-300 hover:text-slate-950"
            >
              Public site
            </Link>
            <button
              onClick={() => loadWorkspace()}
              className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-600 transition hover:border-slate-300 hover:text-slate-950"
            >
              Refresh
            </button>
            <button
              onClick={lockWorkspace}
              className="rounded-full bg-slate-950 px-4 py-2 text-sm font-medium text-white transition hover:bg-slate-800"
            >
              Lock
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto grid max-w-[1500px] gap-6 px-5 py-6 lg:grid-cols-[220px_minmax(0,1fr)] lg:px-8">
        <aside>
          <nav className="sticky top-24 space-y-1 rounded-3xl border border-slate-200 bg-white p-3 shadow-sm">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full rounded-2xl px-4 py-3 text-left text-sm font-medium transition ${
                  activeTab === tab.id
                    ? "bg-slate-950 text-white"
                    : "text-slate-600 hover:bg-slate-100 hover:text-slate-950"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>
        </aside>

        <section className="min-w-0">
          {error ? (
            <div className="mb-5 rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">
              {error}
            </div>
          ) : null}

          {loading ? (
            <div className="rounded-3xl border border-slate-200 bg-white p-10 text-sm text-slate-500">
              Loading sourcing workspace...
            </div>
          ) : null}

          {!loading && activeTab === "overview" ? (
            <div>
              <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
                <div>
                  <p className="text-sm font-medium text-cyan-700">Command center</p>
                  <h1 className="mt-2 text-3xl font-semibold tracking-tight">
                    Sourcing pipeline
                  </h1>
                  <p className="mt-2 text-sm text-slate-500">
                    One view of demand, supply and open commercial work.
                  </p>
                </div>
                <button
                  onClick={() => setActiveTab("agent")}
                  className="rounded-2xl bg-cyan-600 px-5 py-3 text-sm font-semibold text-white transition hover:bg-cyan-700"
                >
                  Ask AI Copilot
                </button>
              </div>

              <div className="mt-7 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                <Metric
                  label="Active projects"
                  value={activeProjects}
                  note={`${data.projects.length} total projects`}
                />
                <Metric
                  label="Suppliers"
                  value={data.suppliers.length}
                  note={`${highRiskSuppliers} currently high risk`}
                />
                <Metric
                  label="Open RFQs"
                  value={
                    data.rfqs.filter(
                      (rfq) =>
                        !["closed", "won", "lost"].includes(
                          (rfq.status || "").toLowerCase()
                        )
                    ).length
                  }
                  note={`${data.rfqs.length} total RFQs`}
                />
                <Metric
                  label="Incoming inquiries"
                  value={data.inquiries.length}
                  note="Latest 50 customer submissions"
                />
              </div>

              <div className="mt-6 grid gap-6 xl:grid-cols-2">
                <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold">Recent projects</p>
                      <p className="mt-1 text-xs text-slate-500">
                        Commercial work currently in motion
                      </p>
                    </div>
                    <button
                      onClick={() => setActiveTab("projects")}
                      className="text-sm font-medium text-cyan-700"
                    >
                      View all
                    </button>
                  </div>

                  <div className="mt-5 space-y-3">
                    {data.projects.slice(0, 5).map((project) => (
                      <div
                        key={project.id}
                        className="flex items-center justify-between gap-4 rounded-2xl bg-slate-50 p-4"
                      >
                        <div className="min-w-0">
                          <p className="truncate text-sm font-medium">
                            {project.name}
                          </p>
                          <p className="mt-1 truncate text-xs text-slate-500">
                            {[project.client_name, project.country, project.category]
                              .filter(Boolean)
                              .join(" · ") || "No metadata"}
                          </p>
                        </div>
                        <div className="text-right">
                          <Badge value={project.status}>
                            {project.status || "active"}
                          </Badge>
                          <p className="mt-2 text-xs text-slate-500">
                            {formatMoney(project.target_budget, project.currency)}
                          </p>
                        </div>
                      </div>
                    ))}

                    {!data.projects.length ? (
                      <Empty>Create your first sourcing project.</Empty>
                    ) : null}
                  </div>
                </div>

                <div className="rounded-3xl border border-slate-200 bg-slate-950 p-6 text-white shadow-sm">
                  <p className="text-sm font-medium text-cyan-300">AI Copilot</p>
                  <h2 className="mt-3 text-2xl font-semibold tracking-tight">
                    Give the database a voice.
                  </h2>
                  <p className="mt-3 max-w-xl text-sm leading-6 text-slate-300">
                    Ask which suppliers fit a project, what information is missing
                    from an RFQ, or what should be followed up next. The Copilot
                    reads current workspace records before it answers.
                  </p>

                  <div className="mt-6 flex flex-wrap gap-2">
                    {[
                      "Which active project needs attention first?",
                      "Compare supplier risk across the database.",
                      "What information is missing from our RFQs?",
                    ].map((prompt) => (
                      <button
                        key={prompt}
                        onClick={() => {
                          setAgentInput(prompt);
                          setActiveTab("agent");
                        }}
                        className="rounded-full bg-white/10 px-3 py-2 text-left text-xs text-slate-200 transition hover:bg-white/15"
                      >
                        {prompt}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ) : null}

          {!loading && activeTab === "projects" ? (
            <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_360px]">
              <div>
                <h1 className="text-3xl font-semibold tracking-tight">Projects</h1>
                <p className="mt-2 text-sm text-slate-500">
                  Client demand translated into sourcing work.
                </p>

                <div className="mt-6 overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm">
                      <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
                        <tr>
                          <th className="px-5 py-4">Project</th>
                          <th className="px-5 py-4">Market</th>
                          <th className="px-5 py-4">Budget</th>
                          <th className="px-5 py-4">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {data.projects.map((project) => (
                          <tr key={project.id}>
                            <td className="px-5 py-4">
                              <p className="font-medium">{project.name}</p>
                              <p className="mt-1 text-xs text-slate-500">
                                {project.client_name || "No client"} ·{" "}
                                {project.category || "Uncategorized"}
                              </p>
                            </td>
                            <td className="px-5 py-4 text-slate-600">
                              {project.country || "—"}
                            </td>
                            <td className="px-5 py-4 text-slate-600">
                              {formatMoney(
                                project.target_budget,
                                project.currency
                              )}
                            </td>
                            <td className="px-5 py-4">
                              <Badge value={project.status}>
                                {project.status || "active"}
                              </Badge>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  {!data.projects.length ? (
                    <div className="p-5">
                      <Empty>No projects yet.</Empty>
                    </div>
                  ) : null}
                </div>
              </div>

              <form
                onSubmit={submitProject}
                className="h-fit rounded-3xl border border-slate-200 bg-white p-5 shadow-sm"
              >
                <p className="font-semibold">New project</p>
                <p className="mt-1 text-xs text-slate-500">
                  Create the commercial container first.
                </p>

                <div className="mt-5 space-y-3">
                  <input
                    required
                    name="name"
                    placeholder="Project name *"
                    className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-cyan-600"
                  />
                  <input
                    name="client_name"
                    placeholder="Client"
                    className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-cyan-600"
                  />
                  <input
                    name="country"
                    placeholder="Destination / market"
                    className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-cyan-600"
                  />
                  <input
                    name="category"
                    placeholder="Category, e.g. inverter"
                    className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-cyan-600"
                  />
                  <div className="grid grid-cols-[1fr_100px] gap-2">
                    <input
                      name="target_budget"
                      type="number"
                      min="0"
                      step="0.01"
                      placeholder="Budget"
                      className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-cyan-600"
                    />
                    <select
                      name="currency"
                      defaultValue="USD"
                      className="rounded-xl border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-cyan-600"
                    >
                      <option>USD</option>
                      <option>CNY</option>
                      <option>JPY</option>
                      <option>EUR</option>
                    </select>
                  </div>
                  <select
                    name="status"
                    defaultValue="active"
                    className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-cyan-600"
                  >
                    <option value="active">Active</option>
                    <option value="waiting">Waiting</option>
                    <option value="won">Won</option>
                    <option value="lost">Lost</option>
                  </select>
                  <textarea
                    name="notes"
                    rows={4}
                    placeholder="Commercial notes"
                    className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-cyan-600"
                  />
                </div>

                <button
                  disabled={mutationLoading}
                  className="mt-4 w-full rounded-xl bg-slate-950 px-4 py-3 text-sm font-medium text-white disabled:opacity-50"
                >
                  {mutationLoading ? "Saving..." : "Create project"}
                </button>
              </form>
            </div>
          ) : null}

          {!loading && activeTab === "suppliers" ? (
            <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_360px]">
              <div>
                <h1 className="text-3xl font-semibold tracking-tight">Suppliers</h1>
                <p className="mt-2 text-sm text-slate-500">
                  A lightweight supplier intelligence base.
                </p>

                <div className="mt-6 grid gap-4 md:grid-cols-2 2xl:grid-cols-3">
                  {data.suppliers.map((supplier) => (
                    <article
                      key={supplier.id}
                      className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <p className="font-semibold">{supplier.company_name}</p>
                          <p className="mt-1 text-xs text-slate-500">
                            {supplier.country || "Unknown market"}
                          </p>
                        </div>
                        <Badge value={supplier.risk_level}>
                          {supplier.risk_level || "unknown"} risk
                        </Badge>
                      </div>

                      <div className="mt-5 flex flex-wrap gap-2">
                        {(supplier.categories || []).map((category) => (
                          <span
                            key={category}
                            className="rounded-full bg-cyan-50 px-2.5 py-1 text-xs font-medium text-cyan-700"
                          >
                            {category}
                          </span>
                        ))}
                      </div>

                      <div className="mt-5 border-t border-slate-100 pt-4 text-xs leading-6 text-slate-500">
                        <p>Contact: {supplier.contact_name || "—"}</p>
                        <p>Email: {supplier.email || "—"}</p>
                        <p>
                          Rating:{" "}
                          {supplier.rating !== null &&
                          supplier.rating !== undefined
                            ? `${supplier.rating}/5`
                            : "—"}
                        </p>
                      </div>
                    </article>
                  ))}

                  {!data.suppliers.length ? (
                    <div className="md:col-span-2 2xl:col-span-3">
                      <Empty>No suppliers yet.</Empty>
                    </div>
                  ) : null}
                </div>
              </div>

              <form
                onSubmit={submitSupplier}
                className="h-fit rounded-3xl border border-slate-200 bg-white p-5 shadow-sm"
              >
                <p className="font-semibold">New supplier</p>
                <p className="mt-1 text-xs text-slate-500">
                  Store facts first, let AI reason over them later.
                </p>

                <div className="mt-5 space-y-3">
                  <input
                    required
                    name="company_name"
                    placeholder="Company name *"
                    className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-cyan-600"
                  />
                  <input
                    name="country"
                    placeholder="Country"
                    className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-cyan-600"
                  />
                  <input
                    name="categories"
                    placeholder="Categories, comma separated"
                    className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-cyan-600"
                  />
                  <input
                    name="contact_name"
                    placeholder="Contact"
                    className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-cyan-600"
                  />
                  <input
                    name="email"
                    type="email"
                    placeholder="Email"
                    className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-cyan-600"
                  />
                  <input
                    name="phone"
                    placeholder="Phone / WeChat / WhatsApp"
                    className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-cyan-600"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      name="rating"
                      type="number"
                      min="0"
                      max="5"
                      step="0.1"
                      placeholder="Rating 0-5"
                      className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-cyan-600"
                    />
                    <select
                      name="risk_level"
                      defaultValue="unknown"
                      className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-cyan-600"
                    >
                      <option value="unknown">Unknown risk</option>
                      <option value="low">Low risk</option>
                      <option value="medium">Medium risk</option>
                      <option value="high">High risk</option>
                    </select>
                  </div>
                  <textarea
                    name="notes"
                    rows={4}
                    placeholder="Capabilities, certificates, constraints..."
                    className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-cyan-600"
                  />
                </div>

                <button
                  disabled={mutationLoading}
                  className="mt-4 w-full rounded-xl bg-slate-950 px-4 py-3 text-sm font-medium text-white disabled:opacity-50"
                >
                  {mutationLoading ? "Saving..." : "Create supplier"}
                </button>
              </form>
            </div>
          ) : null}

          {!loading && activeTab === "rfqs" ? (
            <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_360px]">
              <div>
                <h1 className="text-3xl font-semibold tracking-tight">RFQ</h1>
                <p className="mt-2 text-sm text-slate-500">
                  Turn sourcing requirements into comparable requests.
                </p>

                <div className="mt-6 space-y-3">
                  {data.rfqs.map((rfq) => (
                    <article
                      key={rfq.id}
                      className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm"
                    >
                      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-start">
                        <div>
                          <p className="font-semibold">{rfq.title}</p>
                          <p className="mt-1 text-xs text-slate-500">
                            {rfq.project_id
                              ? projectNameById[rfq.project_id] || "Unknown project"
                              : "No project"}{" "}
                            · Due {formatDate(rfq.due_date)}
                          </p>
                        </div>
                        <Badge value={rfq.status}>
                          {rfq.status || "draft"}
                        </Badge>
                      </div>

                      <p className="mt-4 text-sm leading-6 text-slate-600">
                        {rfq.specification || "No specification recorded."}
                      </p>

                      <div className="mt-4 flex flex-wrap gap-4 text-xs text-slate-500">
                        <span>Qty: {rfq.quantity || "—"}</span>
                        <span>
                          Target: {formatMoney(rfq.target_price, rfq.currency)}
                        </span>
                      </div>
                    </article>
                  ))}

                  {!data.rfqs.length ? <Empty>No RFQs yet.</Empty> : null}
                </div>
              </div>

              <form
                onSubmit={submitRfq}
                className="h-fit rounded-3xl border border-slate-200 bg-white p-5 shadow-sm"
              >
                <p className="font-semibold">New RFQ</p>
                <p className="mt-1 text-xs text-slate-500">
                  Keep specifications structured enough to compare.
                </p>

                <div className="mt-5 space-y-3">
                  <select
                    name="project_id"
                    defaultValue=""
                    className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-cyan-600"
                  >
                    <option value="">No project</option>
                    {data.projects.map((project) => (
                      <option key={project.id} value={project.id}>
                        {project.name}
                      </option>
                    ))}
                  </select>
                  <input
                    required
                    name="title"
                    placeholder="RFQ title *"
                    className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-cyan-600"
                  />
                  <textarea
                    name="specification"
                    rows={5}
                    placeholder="Technical specification"
                    className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-cyan-600"
                  />
                  <input
                    name="quantity"
                    placeholder="Quantity"
                    className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-cyan-600"
                  />
                  <div className="grid grid-cols-[1fr_100px] gap-2">
                    <input
                      name="target_price"
                      type="number"
                      min="0"
                      step="0.01"
                      placeholder="Target price"
                      className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-cyan-600"
                    />
                    <select
                      name="currency"
                      defaultValue="USD"
                      className="rounded-xl border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-cyan-600"
                    >
                      <option>USD</option>
                      <option>CNY</option>
                      <option>JPY</option>
                      <option>EUR</option>
                    </select>
                  </div>
                  <input
                    name="due_date"
                    type="date"
                    className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-cyan-600"
                  />
                  <select
                    name="status"
                    defaultValue="draft"
                    className="w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-cyan-600"
                  >
                    <option value="draft">Draft</option>
                    <option value="sent">Sent</option>
                    <option value="waiting">Waiting</option>
                    <option value="quoted">Quoted</option>
                    <option value="closed">Closed</option>
                  </select>
                </div>

                <button
                  disabled={mutationLoading}
                  className="mt-4 w-full rounded-xl bg-slate-950 px-4 py-3 text-sm font-medium text-white disabled:opacity-50"
                >
                  {mutationLoading ? "Saving..." : "Create RFQ"}
                </button>
              </form>
            </div>
          ) : null}

          {!loading && activeTab === "inquiries" ? (
            <div>
              <h1 className="text-3xl font-semibold tracking-tight">Inquiries</h1>
              <p className="mt-2 text-sm text-slate-500">
                Existing public form submissions, now visible inside the operating
                workspace.
              </p>

              <div className="mt-6 space-y-3">
                {data.inquiries.map((inquiry) => (
                  <article
                    key={inquiry.id}
                    className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm"
                  >
                    <div className="flex flex-col justify-between gap-4 sm:flex-row">
                      <div>
                        <p className="font-semibold">
                          {inquiry.product_name || "Unspecified product"}
                        </p>
                        <p className="mt-1 text-xs text-slate-500">
                          {inquiry.company_name || "Unknown company"} ·{" "}
                          {inquiry.country || "Unknown market"} ·{" "}
                          {formatDate(inquiry.created_at)}
                        </p>
                      </div>
                      <p className="text-sm text-slate-600">
                        {inquiry.quantity || "No quantity"}
                      </p>
                    </div>
                    <p className="mt-4 text-sm leading-6 text-slate-600">
                      {inquiry.message || "No detailed message."}
                    </p>
                    <div className="mt-4 flex flex-wrap gap-4 border-t border-slate-100 pt-4 text-xs text-slate-500">
                      <span>{inquiry.email || "No email"}</span>
                      <span>{inquiry.model_number || "No model"}</span>
                    </div>
                  </article>
                ))}

                {!data.inquiries.length ? (
                  <Empty>No public inquiries loaded.</Empty>
                ) : null}
              </div>
            </div>
          ) : null}

          {!loading && activeTab === "agent" ? (
            <div className="grid min-h-[70vh] overflow-hidden rounded-[2rem] border border-slate-200 bg-white shadow-sm lg:grid-cols-[minmax(0,1fr)_300px]">
              <div className="flex min-h-[70vh] flex-col">
                <div className="border-b border-slate-100 p-5">
                  <p className="text-sm font-semibold">Blue Whale AI Copilot</p>
                  <p className="mt-1 text-xs text-slate-500">
                    Reads current Projects, Suppliers, RFQs and recent Inquiries
                    before answering.
                  </p>
                </div>

                <div className="flex-1 space-y-4 overflow-y-auto bg-slate-50 p-5">
                  {!agentMessages.length ? (
                    <div className="mx-auto max-w-xl py-16 text-center">
                      <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-slate-950 font-semibold text-white">
                        AI
                      </div>
                      <h2 className="mt-5 text-xl font-semibold">
                        Start with the business question.
                      </h2>
                      <p className="mt-2 text-sm leading-6 text-slate-500">
                        The V0.1 Copilot is an analyst, not an autonomous buyer.
                        It reasons over your database but does not silently modify
                        records.
                      </p>
                    </div>
                  ) : null}

                  {agentMessages.map((msg, index) => (
                    <div
                      key={`${msg.role}-${index}`}
                      className={`flex ${
                        msg.role === "user" ? "justify-end" : "justify-start"
                      }`}
                    >
                      <div
                        className={`max-w-2xl whitespace-pre-wrap rounded-3xl px-5 py-4 text-sm leading-6 ${
                          msg.role === "user"
                            ? "bg-slate-950 text-white"
                            : "border border-slate-200 bg-white text-slate-700"
                        }`}
                      >
                        {msg.content}
                      </div>
                    </div>
                  ))}

                  {agentLoading ? (
                    <div className="flex justify-start">
                      <div className="rounded-3xl border border-slate-200 bg-white px-5 py-4 text-sm text-slate-500">
                        Analyzing current sourcing data...
                      </div>
                    </div>
                  ) : null}
                </div>

                <form
                  onSubmit={askAgent}
                  className="border-t border-slate-100 bg-white p-4"
                >
                  <div className="flex gap-3">
                    <textarea
                      value={agentInput}
                      onChange={(e) => setAgentInput(e.target.value)}
                      rows={2}
                      placeholder="Ask about suppliers, active projects, RFQ gaps, risk or next actions..."
                      className="min-h-[58px] flex-1 resize-none rounded-2xl border border-slate-300 px-4 py-3 text-sm outline-none focus:border-cyan-600 focus:ring-4 focus:ring-cyan-100"
                    />
                    <button
                      disabled={!agentInput.trim() || agentLoading}
                      className="rounded-2xl bg-cyan-600 px-5 text-sm font-semibold text-white transition hover:bg-cyan-700 disabled:opacity-50"
                    >
                      Send
                    </button>
                  </div>
                </form>
              </div>

              <aside className="border-t border-slate-200 bg-slate-950 p-5 text-white lg:border-l lg:border-t-0">
                <p className="text-xs font-semibold uppercase tracking-[0.18em] text-cyan-300">
                  Context snapshot
                </p>

                <div className="mt-6 space-y-4">
                  <div className="rounded-2xl bg-white/10 p-4">
                    <p className="text-2xl font-semibold">{data.projects.length}</p>
                    <p className="mt-1 text-xs text-slate-300">projects visible</p>
                  </div>
                  <div className="rounded-2xl bg-white/10 p-4">
                    <p className="text-2xl font-semibold">{data.suppliers.length}</p>
                    <p className="mt-1 text-xs text-slate-300">suppliers visible</p>
                  </div>
                  <div className="rounded-2xl bg-white/10 p-4">
                    <p className="text-2xl font-semibold">{data.rfqs.length}</p>
                    <p className="mt-1 text-xs text-slate-300">RFQs visible</p>
                  </div>
                </div>

                <p className="mt-6 text-xs leading-5 text-slate-400">
                  V0.1 deliberately keeps AI read-only. Once the data model settles,
                  the next version can add controlled tools such as create RFQ,
                  update supplier status and prepare comparison sheets.
                </p>
              </aside>
            </div>
          ) : null}
        </section>
      </div>
    </main>
  );
}
