export function verifyWorkspaceKey(req: Request) {
  const configuredKey = process.env.BLUEWHALE_ADMIN_KEY;

  if (!configuredKey) {
    return {
      ok: false,
      status: 503,
      error: "BLUEWHALE_ADMIN_KEY is not configured.",
    };
  }

  const providedKey = req.headers.get("x-admin-key") || "";

  if (providedKey !== configuredKey) {
    return {
      ok: false,
      status: 401,
      error: "Unauthorized",
    };
  }

  return { ok: true, status: 200, error: "" };
}
