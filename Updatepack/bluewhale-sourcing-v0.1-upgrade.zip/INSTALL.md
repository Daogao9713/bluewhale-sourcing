# Blue Whale Sourcing OS V0.1 - Installation

This package is an **overlay** for the existing `bluewhale-sourcing` Next.js repository.
It does not replace the current public homepage, inquiry form, Supabase client or Resend mail flow.

## What it adds

- `/workspace` internal sourcing dashboard
- Projects
- Suppliers
- RFQs
- Existing public inquiries in the same workspace
- Read-only AI Copilot grounded in current Supabase records
- Simple workspace access key guard
- Supabase schema for the new business objects

## 1. Back up / create a branch

Recommended:

```bash
git checkout -b bluewhale-v0.1
```

## 2. Copy this package over the repository root

Windows PowerShell:

```powershell
.\install.ps1 "C:\path\to\bluewhale-sourcing"
```

macOS / Linux:

```bash
chmod +x install.sh
./install.sh /path/to/bluewhale-sourcing
```

The installer only copies the new V0.1 files. It does not delete existing files.

## 3. Run the SQL migration

Open your Supabase project -> SQL Editor.

Run:

`supabase/bluewhale_v01.sql`

The script creates:

- `projects`
- `suppliers`
- `rfqs`

RLS is enabled and no public read/write policies are created.
The internal API continues to use the server-side service role key already present in the current project.

## 4. Add environment variables

In local `.env.local` and in the Vercel project settings add:

```env
BLUEWHALE_ADMIN_KEY=your-long-random-private-key
OPENAI_API_KEY=your-openai-key
OPENAI_MODEL=gpt-5.6-luna
```

Keep the existing Supabase / Resend variables.

`BLUEWHALE_ADMIN_KEY` is a V0.1 operator gate, not enterprise authentication.
Do not reuse a personal password.

## 5. Install / build

No new npm packages are required.

```bash
npm install
npm run build
npm run dev
```

Then open:

`http://localhost:3000/workspace`

## 6. Test in this order

1. Unlock `/workspace`.
2. Create one Project.
3. Create two Suppliers.
4. Create one RFQ linked to the Project.
5. Confirm the existing Inquiries tab loads your public inquiry records.
6. Open AI Copilot and ask:
   - `这个项目现在缺什么信息？`
   - `哪几个供应商风险最高？`
   - `给我一份下一步采购行动清单。`

## Architecture

```text
Public website
  -> existing /api/inquiry
  -> existing inquiries table + Resend

Internal /workspace
  -> /api/workspace
  -> projects / suppliers / rfqs / inquiries

AI Copilot
  -> /api/agent
  -> server reads current Supabase records
  -> OpenAI Responses API
  -> read-only sourcing analysis
```

## Why AI is read-only in V0.1

The first milestone is to stabilize the business objects and UI.
AI is intentionally not allowed to silently create/update suppliers, RFQs or projects yet.

V0.2 can add explicit, auditable tools such as:

- create RFQ draft
- update project status
- attach a supplier to a project
- generate supplier comparison
- convert an incoming inquiry into a sourcing project

That is safer and more useful than giving an immature agent broad write access on day one.
