param(
  [Parameter(Mandatory=$true)]
  [string]$Target
)

$ErrorActionPreference = "Stop"

if (-not (Test-Path $Target)) {
  throw "Target directory does not exist: $Target"
}

$Source = Split-Path -Parent $MyInvocation.MyCommand.Path

$Files = @(
  "lib/workspace-auth.ts",
  "app/workspace/page.tsx",
  "app/api/workspace/route.ts",
  "app/api/agent/route.ts",
  "components/WorkspaceShell.tsx",
  "supabase/bluewhale_v01.sql",
  ".env.example.additions",
  "INSTALL.md"
)

foreach ($File in $Files) {
  $From = Join-Path $Source $File
  $To = Join-Path $Target $File
  $Dir = Split-Path -Parent $To

  if (-not (Test-Path $Dir)) {
    New-Item -ItemType Directory -Force -Path $Dir | Out-Null
  }

  Copy-Item -Force $From $To
  Write-Host "Installed $File"
}

Write-Host ""
Write-Host "Blue Whale Sourcing OS V0.1 overlay installed."
Write-Host "Next: run supabase/bluewhale_v01.sql and configure environment variables."
