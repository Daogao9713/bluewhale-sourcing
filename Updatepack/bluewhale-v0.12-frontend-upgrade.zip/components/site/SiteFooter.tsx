import Link from "next/link";

export default function SiteFooter() {
  return (
    <footer className="border-t border-slate-200 bg-slate-950 text-white">
      <div className="site-shell grid gap-10 py-14 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <div className="flex items-center gap-3">
            <div className="brand-mark brand-mark-light">BW</div>
            <div>
              <p className="font-semibold">江苏蓝鲸新能源有限公司</p>
              <p className="mt-1 text-xs tracking-[0.18em] text-slate-400">
                BLUE WHALE NEW ENERGY
              </p>
            </div>
          </div>
          <p className="mt-5 max-w-md text-sm leading-7 text-slate-400">
            面向新能源产业与全球供应链场景，提供产业连接、技术协同、跨境商务与数字化能力。
          </p>
        </div>

        <div>
          <p className="text-sm font-semibold">快速导航</p>
          <div className="mt-4 grid gap-3 text-sm text-slate-400">
            <Link href="/about" className="hover:text-white">关于我们</Link>
            <Link href="/business" className="hover:text-white">业务领域</Link>
            <Link href="/technology" className="hover:text-white">技术与创新</Link>
            <Link href="/business/sourcing" className="hover:text-white">全球采购与供应链</Link>
          </div>
        </div>

        <div>
          <p className="text-sm font-semibold">合作入口</p>
          <div className="mt-4 grid gap-3 text-sm text-slate-400">
            <Link href="/inquiry" className="hover:text-white">提交业务需求</Link>
            <Link href="/contact" className="hover:text-white">联系团队</Link>
            <Link href="/workspace" className="hover:text-white">内部 Sourcing OS</Link>
          </div>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="site-shell flex flex-col gap-2 py-5 text-xs text-slate-500 sm:flex-row sm:items-center sm:justify-between">
          <span>© 2026 Blue Whale New Energy. All rights reserved.</span>
          <span>Website release · V0.12</span>
        </div>
      </div>
    </footer>
  );
}
