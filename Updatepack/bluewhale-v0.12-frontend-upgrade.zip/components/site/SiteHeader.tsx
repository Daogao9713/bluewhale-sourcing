"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";

const nav = [
  { href: "/", label: "首页" },
  { href: "/about", label: "关于我们" },
  { href: "/business", label: "业务领域" },
  { href: "/technology", label: "技术与创新" },
  { href: "/contact", label: "联系我们" },
];

export default function SiteHeader() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  return (
    <header className="site-header">
      <div className="site-shell flex h-[76px] items-center justify-between">
        <Link href="/" className="flex items-center gap-3" onClick={() => setOpen(false)}>
          <div className="brand-mark">BW</div>
          <div>
            <div className="text-[15px] font-semibold tracking-[-0.01em] text-slate-950">
              BLUE WHALE
            </div>
            <div className="text-[10px] font-medium tracking-[0.18em] text-slate-500">
              NEW ENERGY
            </div>
          </div>
        </Link>

        <nav className="hidden items-center gap-1 lg:flex">
          {nav.map((item) => {
            const active =
              item.href === "/"
                ? pathname === "/"
                : pathname.startsWith(item.href);

            return (
              <Link
                key={item.href}
                href={item.href}
                className={`site-nav-link ${active ? "site-nav-link-active" : ""}`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="hidden items-center gap-2 lg:flex">
          <Link href="/workspace" className="btn-ghost">
            Sourcing OS
          </Link>
          <Link href="/inquiry" className="btn-primary">
            提交需求
          </Link>
        </div>

        <button
          type="button"
          aria-label="Toggle menu"
          onClick={() => setOpen((value) => !value)}
          className="flex h-11 w-11 items-center justify-center rounded-2xl border border-slate-200 bg-white lg:hidden"
        >
          <span className="text-xl">{open ? "×" : "☰"}</span>
        </button>
      </div>

      {open ? (
        <div className="border-t border-slate-100 bg-white lg:hidden">
          <div className="site-shell space-y-1 py-4">
            {nav.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className="block rounded-2xl px-4 py-3 text-sm font-medium text-slate-700 hover:bg-slate-50"
              >
                {item.label}
              </Link>
            ))}
            <div className="grid grid-cols-2 gap-2 pt-3">
              <Link href="/workspace" onClick={() => setOpen(false)} className="btn-ghost justify-center">
                Sourcing OS
              </Link>
              <Link href="/inquiry" onClick={() => setOpen(false)} className="btn-primary justify-center">
                提交需求
              </Link>
            </div>
          </div>
        </div>
      ) : null}
    </header>
  );
}
