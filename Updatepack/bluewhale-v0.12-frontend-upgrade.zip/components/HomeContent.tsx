import Link from "next/link";
import CompanySiteLayout from "@/components/site/CompanySiteLayout";

const capabilities = [
  {
    code: "01",
    title: "新能源产业协同",
    desc: "围绕新能源设备、零部件与产业资源，建立跨企业、跨区域的协作连接。",
    tag: "ENERGY",
  },
  {
    code: "02",
    title: "全球商务连接",
    desc: "支持中国、日本及全球市场之间的商务沟通、合作对接与跨境项目推进。",
    tag: "GLOBAL",
  },
  {
    code: "03",
    title: "供应链与采购服务",
    desc: "为明确采购需求提供供应商匹配、询报价、样品、物流与交付协同。",
    tag: "SOURCING",
  },
  {
    code: "04",
    title: "数字化业务工具",
    desc: "通过内部 Sourcing OS 与 AI 辅助能力，让项目、供应商与业务信息更可管理。",
    tag: "DIGITAL",
  },
];

const pillars = [
  { value: "3", label: "语言协作", sub: "中文 / 日本語 / English" },
  { value: "2", label: "核心市场", sub: "China / Japan + Global" },
  { value: "AI", label: "数字能力", sub: "Sourcing OS / Copilot" },
  { value: "∞", label: "产业连接", sub: "持续扩展合作网络" },
];

const business = [
  {
    index: "A",
    title: "新能源产业合作",
    desc: "围绕储能、电力电子、工业设备及上下游资源，推动企业间技术与商务连接。",
    href: "/business",
  },
  {
    index: "B",
    title: "全球采购与供应链",
    desc: "将采购作为独立业务模块，为有明确需求的客户提供端到端 sourcing 支持。",
    href: "/business/sourcing",
  },
  {
    index: "C",
    title: "跨境商务支持",
    desc: "协助中日及国际企业进行信息整理、多语言沟通、伙伴对接和项目推进。",
    href: "/business",
  },
];

export default function HomeContent() {
  return (
    <CompanySiteLayout>
      <main className="overflow-hidden bg-white">
        <section className="hero-mesh relative min-h-[760px] border-b border-slate-200">
          <div className="hero-grid absolute inset-0 opacity-60" />
          <div className="hero-orb hero-orb-one" />
          <div className="hero-orb hero-orb-two" />

          <div className="site-shell relative z-10 grid min-h-[760px] items-center gap-12 py-24 lg:grid-cols-[1.12fr_0.88fr]">
            <div>
              <div className="eyebrow">
                <span className="eyebrow-dot" />
                BLUE WHALE NEW ENERGY · 0.12
              </div>

              <h1 className="mt-7 max-w-4xl text-[clamp(3.2rem,8vw,7.5rem)] font-semibold leading-[0.88] tracking-[-0.065em] text-slate-950">
                Connecting
                <br />
                <span className="text-gradient">Energy.</span>
                <br />
                Building Value.
              </h1>

              <p className="mt-8 max-w-2xl text-base leading-8 text-slate-600 md:text-lg">
                江苏蓝鲸新能源有限公司，以新能源产业为核心连接点，
                延伸至全球商务、供应链协同与数字化业务工具，
                为合作伙伴建立更高效、更清晰的跨区域协作路径。
              </p>

              <div className="mt-10 flex flex-wrap gap-3">
                <Link href="/business" className="btn-primary btn-large">
                  探索业务领域
                </Link>
                <Link href="/about" className="btn-ghost btn-large">
                  了解蓝鲸
                </Link>
              </div>
            </div>

            <div className="relative lg:pl-8">
              <div className="relative overflow-hidden rounded-[2.2rem] border border-slate-200 bg-slate-950 p-7 shadow-2xl shadow-cyan-900/10 md:p-9">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,rgba(34,211,238,.16),transparent_30%)]" />

                <div className="relative">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-semibold tracking-[0.2em] text-cyan-300">
                      COMPANY SYSTEM
                    </p>
                    <span className="status-chip">ONLINE</span>
                  </div>

                  <div className="mt-10 grid gap-3 sm:grid-cols-2">
                    {pillars.map((item) => (
                      <div
                        key={item.label}
                        className="rounded-3xl border border-white/10 bg-white/[0.06] p-5"
                      >
                        <div className="text-3xl font-semibold tracking-[-0.04em] text-white">
                          {item.value}
                        </div>
                        <div className="mt-5 text-sm font-medium text-white">
                          {item.label}
                        </div>
                        <div className="mt-1 text-xs text-slate-400">{item.sub}</div>
                      </div>
                    ))}
                  </div>

                  <div className="mt-7 border-t border-white/10 pt-6">
                    <div className="flex items-center justify-between text-xs text-slate-400">
                      <span>BLUE WHALE / JIANGSU</span>
                      <span>CHINA · JAPAN · GLOBAL</span>
                    </div>
                    <div className="mt-4 h-1 overflow-hidden rounded-full bg-white/10">
                      <div className="h-full w-3/4 rounded-full bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500" />
                    </div>
                  </div>
                </div>
              </div>

              <div className="floating-note">
                <span className="h-2 w-2 rounded-full bg-cyan-500" />
                <span>产业 + 商务 + 数字系统</span>
              </div>
            </div>
          </div>
        </section>

        <section className="site-shell py-24 md:py-32">
          <div className="grid gap-10 lg:grid-cols-[0.75fr_1.25fr]">
            <div>
              <p className="section-kicker">WHAT WE DO</p>
              <h2 className="section-title mt-4">
                不把公司定义成
                <br />
                单一采购服务商。
              </h2>
            </div>
            <div className="max-w-3xl text-base leading-8 text-slate-600 md:text-lg">
              蓝鲸新能源的官网与业务体系从 0.12 开始采用更宽的企业定位。
              采购与供应链是业务能力之一，但不是全部。我们更关注新能源产业中的
              <strong className="font-semibold text-slate-950">
                资源连接、项目协同、跨境沟通、数字化运营
              </strong>
              ，并让各业务模块保持可独立扩展。
            </div>
          </div>

          <div className="mt-16 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            {capabilities.map((item) => (
              <article key={item.code} className="capability-card group">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold tracking-[0.18em] text-slate-400">
                    {item.code}
                  </span>
                  <span className="rounded-full border border-slate-200 px-2.5 py-1 text-[10px] font-semibold tracking-wider text-slate-500">
                    {item.tag}
                  </span>
                </div>
                <div className="mt-20">
                  <h3 className="text-xl font-semibold tracking-[-0.025em] text-slate-950">
                    {item.title}
                  </h3>
                  <p className="mt-4 text-sm leading-7 text-slate-600">{item.desc}</p>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="bg-slate-950 py-24 text-white md:py-32">
          <div className="site-shell">
            <div className="grid gap-8 lg:grid-cols-2 lg:items-end">
              <div>
                <p className="section-kicker text-cyan-300">BUSINESS MATRIX</p>
                <h2 className="mt-4 max-w-3xl text-4xl font-semibold tracking-[-0.045em] md:text-6xl">
                  一个官网，
                  <br />
                  多个可独立生长的业务模块。
                </h2>
              </div>
              <p className="max-w-xl text-sm leading-7 text-slate-400 lg:justify-self-end">
                前端信息架构不再围绕“提交询价”展开，而是先建立企业认知，
                再让不同客户进入对应业务页面。
              </p>
            </div>

            <div className="mt-14 divide-y divide-white/10 border-y border-white/10">
              {business.map((item) => (
                <Link
                  key={item.index}
                  href={item.href}
                  className="business-row group grid gap-5 py-8 md:grid-cols-[80px_1fr_1fr_60px] md:items-center"
                >
                  <span className="text-xs font-semibold tracking-[0.2em] text-cyan-300">
                    {item.index}
                  </span>
                  <h3 className="text-2xl font-semibold tracking-[-0.03em]">
                    {item.title}
                  </h3>
                  <p className="text-sm leading-6 text-slate-400">{item.desc}</p>
                  <span className="text-right text-2xl text-slate-500 transition group-hover:translate-x-1 group-hover:text-white">
                    →
                  </span>
                </Link>
              ))}
            </div>
          </div>
        </section>

        <section className="site-shell py-24 md:py-32">
          <div className="rounded-[2.5rem] border border-slate-200 bg-[linear-gradient(135deg,#f8fafc_0%,#ecfeff_50%,#eff6ff_100%)] p-8 md:p-14">
            <div className="grid gap-12 lg:grid-cols-[1fr_1fr] lg:items-center">
              <div>
                <p className="section-kicker">DIGITAL LAYER</p>
                <h2 className="section-title mt-4">
                  让业务系统成为
                  <br />
                  公司能力的一部分。
                </h2>
                <p className="mt-6 max-w-xl text-sm leading-7 text-slate-600">
                  蓝鲸内部 Sourcing OS 已开始管理项目、供应商、RFQ 与业务信息。
                  后续 AI、知识库、项目协作等能力可以持续演进，而官网保持稳定。
                </p>
                <div className="mt-8 flex flex-wrap gap-3">
                  <Link href="/technology" className="btn-primary">
                    查看技术路线
                  </Link>
                  <Link href="/workspace" className="btn-ghost">
                    进入 Sourcing OS
                  </Link>
                </div>
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                {[
                  ["Projects", "项目与机会管理", "01"],
                  ["Suppliers", "供应商能力数据库", "02"],
                  ["RFQ", "询报价流程结构化", "03"],
                  ["AI Copilot", "基于业务数据的分析", "04"],
                ].map(([name, desc, no]) => (
                  <div key={name} className="rounded-3xl border border-white bg-white/80 p-5 shadow-sm">
                    <div className="text-xs font-semibold text-cyan-700">{no}</div>
                    <div className="mt-8 text-lg font-semibold">{name}</div>
                    <div className="mt-2 text-sm text-slate-500">{desc}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="border-t border-slate-200 bg-white py-24">
          <div className="site-shell grid gap-10 lg:grid-cols-[1fr_auto] lg:items-end">
            <div>
              <p className="section-kicker">WORK WITH BLUE WHALE</p>
              <h2 className="mt-4 max-w-4xl text-4xl font-semibold tracking-[-0.045em] text-slate-950 md:text-6xl">
                有明确项目，也可以只有一个合作想法。
              </h2>
            </div>
            <div className="flex flex-wrap gap-3">
              <Link href="/contact" className="btn-ghost btn-large">
                联系团队
              </Link>
              <Link href="/inquiry" className="btn-primary btn-large">
                提交业务需求
              </Link>
            </div>
          </div>
        </section>
      </main>
    </CompanySiteLayout>
  );
}
