import CompanySiteLayout from "@/components/site/CompanySiteLayout";

export default function AboutPage() {
  return (
    <CompanySiteLayout>
      <main>
        <section className="page-hero">
          <div className="hero-grid absolute inset-0 opacity-40" />
          <div className="site-shell relative z-10 py-24 md:py-32">
            <p className="section-kicker">ABOUT BLUE WHALE</p>
            <h1 className="page-title mt-5">
              用更开放的方式，
              <br />
              连接新能源产业价值。
            </h1>
            <p className="page-lead">
              江苏蓝鲸新能源有限公司正在构建一个可持续扩展的企业能力体系：
              以新能源产业为核心，连接全球商务、供应链与数字化工具。
            </p>
          </div>
        </section>

        <section className="site-shell py-24">
          <div className="grid gap-6 md:grid-cols-3">
            {[
              ["定位", "产业连接者", "不局限于单一贸易或采购角色，围绕产业资源与项目协作建立长期价值。"],
              ["市场", "中国 · 日本 · 全球", "利用中日英多语言能力，支持跨文化、跨区域的企业沟通与合作。"],
              ["方法", "长期主义 + 数字化", "将项目数据、供应商信息与业务过程逐步沉淀为企业自己的数字资产。"],
            ].map(([kicker, title, desc]) => (
              <article key={kicker} className="rounded-[2rem] border border-slate-200 bg-white p-7">
                <p className="text-xs font-semibold tracking-[0.18em] text-cyan-700">{kicker}</p>
                <h2 className="mt-8 text-2xl font-semibold tracking-[-0.03em]">{title}</h2>
                <p className="mt-4 text-sm leading-7 text-slate-600">{desc}</p>
              </article>
            ))}
          </div>

          <div className="mt-20 grid gap-10 border-t border-slate-200 pt-16 lg:grid-cols-2">
            <h2 className="section-title">
              从一次合作，
              <br />
              变成可重复的能力。
            </h2>
            <div className="space-y-6 text-sm leading-8 text-slate-600">
              <p>
                公司网站从 V0.12 开始，不再把“海外采购”作为唯一叙事中心。
                采购服务保留并深化，但会作为业务矩阵中的独立二级模块存在。
              </p>
              <p>
                这样的结构更适合后续加入新能源项目合作、产品与技术合作、
                企业服务、数字工具、案例与资讯等内容，而不需要频繁重做首页。
              </p>
            </div>
          </div>
        </section>
      </main>
    </CompanySiteLayout>
  );
}
