import Link from "next/link";
import CompanySiteLayout from "@/components/site/CompanySiteLayout";

export default function TechnologyPage() {
  return (
    <CompanySiteLayout>
      <main>
        <section className="page-hero">
          <div className="site-shell py-24 md:py-32">
            <p className="section-kicker">TECHNOLOGY & INNOVATION</p>
            <h1 className="page-title mt-5">
              技术不是展示，
              <br />
              而是业务基础设施。
            </h1>
            <p className="page-lead">
              Blue Whale 正在把项目、供应商、询报价和 AI 分析逐步沉淀为内部数字系统。
            </p>
          </div>
        </section>

        <section className="site-shell py-24">
          <div className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
            <div className="rounded-[2.5rem] bg-slate-950 p-8 text-white md:p-12">
              <div className="flex items-center justify-between">
                <p className="text-xs font-semibold tracking-[0.2em] text-cyan-300">SOURCING OS</p>
                <span className="status-chip">V0.1+</span>
              </div>
              <h2 className="mt-16 text-4xl font-semibold tracking-[-0.04em]">
                内部业务操作系统
              </h2>
              <p className="mt-5 max-w-xl text-sm leading-7 text-slate-400">
                项目、供应商、RFQ、客户需求与 AI Copilot 在同一工作区中形成统一业务上下文。
              </p>
              <Link href="/workspace" className="btn-light mt-8">
                进入内部系统
              </Link>
            </div>

            <div className="grid gap-4">
              {[
                ["DATA", "结构化数据", "逐步形成可复用的供应商、项目与业务知识资产。"],
                ["AI", "AI Copilot", "基于企业数据提供分析、风险识别与下一步建议。"],
                ["API", "模块化接口", "官网、业务系统与未来第三方服务保持可拆分升级。"],
              ].map(([code, title, desc]) => (
                <div key={code} className="rounded-[2rem] border border-slate-200 bg-white p-6">
                  <p className="text-xs font-semibold text-cyan-700">{code}</p>
                  <h3 className="mt-8 text-xl font-semibold">{title}</h3>
                  <p className="mt-3 text-sm leading-7 text-slate-600">{desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>
    </CompanySiteLayout>
  );
}
