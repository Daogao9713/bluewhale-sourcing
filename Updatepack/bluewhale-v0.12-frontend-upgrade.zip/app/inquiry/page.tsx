"use client";

import { useEffect, useState } from "react";
import InquiryForm from "@/components/InquiryForm";
import { LanguageProvider } from "@/components/LanguageProvider";
import CompanySiteLayout from "@/components/site/CompanySiteLayout";
import translations from "@/lib/translations";

function InquiryContent() {
  const [lang, setLang] = useState<"zh" | "ja" | "en">("zh");

  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const value = params.get("lang");
      if (value === "zh" || value === "ja" || value === "en") {
        setLang(value);
      }
    } catch {
      // Keep default language.
    }
  }, []);

  const t = translations[lang] || translations.zh;

  return (
    <CompanySiteLayout>
      <main className="bg-slate-50">
        <section className="page-hero">
          <div className="site-shell py-16 md:py-24">
            <div className="flex flex-col justify-between gap-8 md:flex-row md:items-end">
              <div>
                <p className="section-kicker">BUSINESS REQUEST</p>
                <h1 className="mt-5 max-w-4xl text-4xl font-semibold tracking-[-0.045em] text-slate-950 md:text-6xl">
                  提交业务与采购需求
                </h1>
                <p className="mt-5 max-w-2xl text-sm leading-7 text-slate-600">
                  {t.intro}
                </p>
              </div>

              <div className="flex gap-2">
                {(["zh", "ja", "en"] as const).map((item) => (
                  <button
                    key={item}
                    onClick={() => setLang(item)}
                    className={`rounded-full px-4 py-2 text-xs font-semibold transition ${
                      lang === item
                        ? "bg-slate-950 text-white"
                        : "border border-slate-200 bg-white text-slate-500 hover:text-slate-950"
                    }`}
                  >
                    {item === "zh" ? "中文" : item === "ja" ? "日本語" : "EN"}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="site-shell grid gap-8 py-12 lg:grid-cols-[0.72fr_1.28fr] lg:items-start">
          <aside className="rounded-[2rem] bg-slate-950 p-7 text-white lg:sticky lg:top-28">
            <p className="text-xs font-semibold tracking-[0.18em] text-cyan-300">
              BEFORE SUBMITTING
            </p>
            <h2 className="mt-8 text-2xl font-semibold tracking-[-0.03em]">
              信息越明确，
              <br />
              后续推进越高效。
            </h2>
            <div className="mt-8 space-y-5 text-sm leading-6 text-slate-400">
              <p>01 · 产品名称、型号与规格</p>
              <p>02 · 数量、目标市场与交付要求</p>
              <p>03 · 预算、目标价格或付款条件</p>
              <p>04 · 认证、样品、物流等特殊要求</p>
            </div>
            <div className="mt-8 border-t border-white/10 pt-6 text-xs leading-6 text-slate-500">
              本表单继续使用现有 Supabase 与邮件通知链路。
            </div>
          </aside>

          <div>
            <InquiryForm />
          </div>
        </section>
      </main>
    </CompanySiteLayout>
  );
}

export default function InquiryPage() {
  return (
    <LanguageProvider>
      <InquiryContent />
    </LanguageProvider>
  );
}
