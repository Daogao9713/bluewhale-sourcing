import Link from "next/link";
import CompanySiteLayout from "@/components/site/CompanySiteLayout";

const items = [
  {
    title: "新能源产业合作",
    desc: "面向储能、电力电子、工业设备与新能源上下游资源，提供项目合作与产业连接。",
    badge: "ENERGY",
  },
  {
    title: "全球采购与供应链",
    desc: "针对明确采购需求，提供供应商匹配、询报价、样品、物流与交付协同。",
    badge: "SOURCING",
    href: "/business/sourcing",
  },
  {
    title: "中日跨境商务支持",
    desc: "提供中日英沟通、商务信息整理、伙伴对接以及跨境项目推进支持。",
    badge: "GLOBAL",
  },
  {
    title: "数字化业务能力",
    desc: "通过内部 Sourcing OS、AI Copilot 与数据结构化，提升业务运营与决策效率。",
    badge: "DIGITAL",
    href: "/technology",
  },
];

export default function BusinessPage() {
  return (
    <CompanySiteLayout>
      <main>
        <section className="page-hero">
          <div className="site-shell py-24 md:py-32">
            <p className="section-kicker">BUSINESS</p>
            <h1 className="page-title mt-5">从单点服务到业务能力矩阵。</h1>
            <p className="page-lead">
              每个业务模块独立发展，又共享公司的产业资源、跨境能力与数字基础设施。
            </p>
          </div>
        </section>

        <section className="site-shell py-24">
          <div className="grid gap-5 md:grid-cols-2">
            {items.map((item, index) => {
              const card = (
                <article className="group h-full rounded-[2rem] border border-slate-200 bg-white p-7 transition hover:-translate-y-1 hover:shadow-xl hover:shadow-slate-200/60">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold tracking-[0.18em] text-slate-400">
                      0{index + 1}
                    </span>
                    <span className="rounded-full bg-slate-950 px-3 py-1 text-[10px] font-semibold tracking-[0.14em] text-white">
                      {item.badge}
                    </span>
                  </div>
                  <h2 className="mt-16 text-3xl font-semibold tracking-[-0.04em]">{item.title}</h2>
                  <p className="mt-4 max-w-xl text-sm leading-7 text-slate-600">{item.desc}</p>
                  {item.href ? (
                    <div className="mt-8 text-sm font-semibold text-cyan-700">
                      查看业务详情 →
                    </div>
                  ) : (
                    <div className="mt-8 text-xs font-medium text-slate-400">持续建设中</div>
                  )}
                </article>
              );

              return item.href ? (
                <Link key={item.title} href={item.href}>
                  {card}
                </Link>
              ) : (
                <div key={item.title}>{card}</div>
              );
            })}
          </div>
        </section>
      </main>
    </CompanySiteLayout>
  );
}
