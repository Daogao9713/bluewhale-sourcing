import Link from "next/link";
import CompanySiteLayout from "@/components/site/CompanySiteLayout";

export default function SourcingPage() {
  return (
    <CompanySiteLayout>
      <main>
        <section className="page-hero">
          <div className="site-shell py-24 md:py-32">
            <p className="section-kicker">BUSINESS / SOURCING</p>
            <h1 className="page-title mt-5">
              全球采购与
              <br />
              供应链协同。
            </h1>
            <p className="page-lead">
              将原先首页的采购能力收拢到独立业务页面，专门服务有明确产品、
              数量、规格、市场或交付目标的客户。
            </p>
            <div className="mt-8">
              <Link href="/inquiry" className="btn-primary btn-large">
                提交采购需求
              </Link>
            </div>
          </div>
        </section>

        <section className="site-shell py-24">
          <div className="grid gap-4 lg:grid-cols-4">
            {[
              ["01", "需求澄清", "产品、规格、数量、认证、目标价与交付市场。"],
              ["02", "供应商匹配", "基于产品能力、区域、历史信息与风险进行筛选。"],
              ["03", "询价与比较", "整理报价、MOQ、交期、付款条件与关键差异。"],
              ["04", "交付协同", "样品、沟通、物流及后续项目推进支持。"],
            ].map(([no, title, desc]) => (
              <article key={no} className="rounded-[2rem] border border-slate-200 bg-white p-6">
                <p className="text-xs font-semibold text-cyan-700">{no}</p>
                <h2 className="mt-12 text-xl font-semibold">{title}</h2>
                <p className="mt-3 text-sm leading-7 text-slate-600">{desc}</p>
              </article>
            ))}
          </div>

          <div className="mt-16 rounded-[2.5rem] bg-slate-950 p-8 text-white md:p-12">
            <p className="section-kicker text-cyan-300">DIGITAL SOURCING</p>
            <div className="mt-4 grid gap-8 lg:grid-cols-[1fr_auto] lg:items-end">
              <div>
                <h2 className="text-3xl font-semibold tracking-[-0.04em] md:text-5xl">
                  采购业务正在接入内部 Sourcing OS。
                </h2>
                <p className="mt-5 max-w-2xl text-sm leading-7 text-slate-400">
                  项目、供应商、RFQ 与 AI 分析逐步进入结构化系统，
                  让采购业务成为公司数字能力的一个应用，而不是整个公司的唯一定位。
                </p>
              </div>
              <Link href="/inquiry" className="btn-light">
                开始询价
              </Link>
            </div>
          </div>
        </section>
      </main>
    </CompanySiteLayout>
  );
}
