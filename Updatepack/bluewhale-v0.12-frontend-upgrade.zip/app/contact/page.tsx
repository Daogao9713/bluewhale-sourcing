import Link from "next/link";
import CompanySiteLayout from "@/components/site/CompanySiteLayout";

export default function ContactPage() {
  return (
    <CompanySiteLayout>
      <main>
        <section className="page-hero">
          <div className="site-shell py-24 md:py-32">
            <p className="section-kicker">CONTACT</p>
            <h1 className="page-title mt-5">谈合作，也谈可能性。</h1>
            <p className="page-lead">
              无论是新能源项目、跨境商务、供应链需求，还是新的产业合作方向，
              都可以从这里开始。
            </p>
          </div>
        </section>

        <section className="site-shell py-24">
          <div className="grid gap-6 md:grid-cols-2">
            <Link
              href="/inquiry"
              className="rounded-[2.5rem] border border-slate-200 bg-slate-950 p-8 text-white transition hover:-translate-y-1"
            >
              <p className="text-xs font-semibold tracking-[0.18em] text-cyan-300">BUSINESS REQUEST</p>
              <h2 className="mt-16 text-3xl font-semibold tracking-[-0.04em]">提交具体业务需求</h2>
              <p className="mt-4 text-sm leading-7 text-slate-400">
                如果已经有产品、数量、项目背景或采购需求，可直接进入现有表单。
              </p>
              <div className="mt-8 font-semibold">进入需求表单 →</div>
            </Link>

            <div className="rounded-[2.5rem] border border-slate-200 bg-white p-8">
              <p className="text-xs font-semibold tracking-[0.18em] text-cyan-700">GENERAL CONTACT</p>
              <h2 className="mt-16 text-3xl font-semibold tracking-[-0.04em]">一般合作与企业联系</h2>
              <p className="mt-4 text-sm leading-7 text-slate-600">
                V0.12 暂不在前端硬编码联系方式。可在下一版接入正式企业邮箱、
                地址、社交账号与 CRM 联系表单。
              </p>
              <p className="mt-8 text-sm font-medium text-slate-400">
                Contact module ready for company information.
              </p>
            </div>
          </div>
        </section>
      </main>
    </CompanySiteLayout>
  );
}
