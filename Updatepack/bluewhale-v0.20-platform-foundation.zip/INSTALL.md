# Blue Whale V0.20 · Platform Foundation

Install on top of V0.18.

## Install

Windows:

```powershell
.\install.ps1 "C:\path\to\bluewhale-sourcing"
```

Then restart Next.js:

```powershell
Ctrl+C
npm run dev
```

Environment variable changes are not reliably picked up by an already-running dev server. Restart after editing `.env.local`.

## Supabase

No new SQL migration is required for V0.20.

Keep:

- V0.1 sourcing tables
- V0.17 Company News migration
- RLS enabled

## DeepSeek

Recommended `.env.local`:

```env
AI_PROVIDER=deepseek
DEEPSEEK_API_KEY=
DEEPSEEK_MODEL=deepseek-chat
DEEPSEEK_BASE_URL=https://api.deepseek.com
```

If your existing DeepSeek key is currently stored as `OPENAI_API_KEY`, V0.20 can fall back to it when `AI_PROVIDER=deepseek`, but using `DEEPSEEK_API_KEY` is clearer.

After editing env:

```powershell
Ctrl+C
npm run dev
```

## OpenAI alternative

```env
AI_PROVIDER=openai
OPENAI_API_KEY=
OPENAI_MODEL=
OPENAI_BASE_URL=https://api.openai.com/v1
```

## News test

1. Open `/workspace/news`.
2. Create or edit an article.
3. Set status to Published.
4. For immediate publication, leave publish time empty or choose the current/past time.
5. Save / Publish.
6. Open `/api/news?limit=50`.
7. Confirm the JSON contains the article.
8. Open `/news`.
9. Open homepage and confirm the news strip contains it.

If `/api/news` contains the article but the page does not, the remaining issue is client rendering/i18n and not the database query.

If `/api/news` does not contain it, inspect `status` and `published_at` in Supabase.

## AI test

Open `/api/health`.

Expected example:

```json
{
  "status": "ok",
  "database": "ok",
  "ai": {
    "provider": "deepseek",
    "configured": true
  }
}
```

Then test the public AI Concierge.

If it fails, the server log now prints a concise provider error/status without exposing the API key.

## Mobile test

Test at approximately:

- 390px width
- 430px width
- 768px width

Check:

- header navigation
- homepage hero
- news ticker
- news list/detail
- inquiry form
- AI Concierge
- `/workspace`
- `/workspace/news`

## Architecture after V0.20

```text
UI
├── Public Website
└── Blue Whale OS
       │
       ▼
Application APIs
├── News
├── Workspace
└── AI
       │
       ├── lib/news
       ├── lib/database
       └── lib/ai
              │
              ├── Supabase
              ├── DeepSeek
              └── OpenAI-compatible provider
```

V0.20 does not attempt a risky monorepo conversion. It creates clean service boundaries inside the existing Next.js application first.
