# Blue Whale V0.20 Changelog

## Release type

Even release with a platform-foundation focus. V0.20 closes the current V0.x website/workspace loop before the next functional cycle.

## News visibility fix

- Public news queries moved into `lib/news/server.ts`.
- Published rows with no `published_at` are now visible.
- Published rows with a past `published_at` are visible.
- Future scheduled rows remain hidden.
- CMS normalizes publish timestamps to ISO.
- Public `/api/news` is force-dynamic and uses `no-store`.
- Homepage and News list fetch with `cache: no-store`.
- CMS PATCH response now includes publication diagnostics.

This addresses the case where CMS shows `PUBLISHED` and Supabase contains the row but the website does not render it.

## AI provider decoupling

- Added `lib/ai/server.ts`.
- Public AI no longer depends on OpenAI Responses API.
- Uses an OpenAI-compatible Chat Completions boundary.
- Supports DeepSeek through `AI_PROVIDER=deepseek`.
- Existing OpenAI configuration remains supported.
- CMS translation uses the same provider layer.
- Provider-specific implementation is isolated from page/API business logic.

## Database decoupling

- Added `lib/database/server.ts`.
- `lib/supabase.ts` and `lib/supabase-admin.ts` are compatibility shims.
- New code should import the database layer, not construct Supabase clients.
- This is the first step toward future CN/Global database adapters.

## Mobile

- Added mobile overflow protection.
- AI Concierge becomes a near-full-width mobile sheet.
- iOS form zoom is prevented with 16px form controls.
- Media elements are constrained to viewport width.
- Workspace V0.18 mobile sidebar remains supported.

## Diagnostics

- Added `/api/health`.
- Reports database health, selected AI provider and whether AI credentials are configured.
- Never returns secret values.
