param([Parameter(Mandatory=$true)][string]$Target)
$ErrorActionPreference = "Stop"
if (-not (Test-Path $Target)) { throw "Target directory does not exist: $Target" }
$Source = Split-Path -Parent $MyInvocation.MyCommand.Path
$Files = @(
  "lib/database/server.ts",
  "lib/ai/server.ts",
  "lib/news/server.ts",
  "lib/supabase.ts",
  "lib/supabase-admin.ts",
  "app/api/news/route.ts",
  "app/api/workspace/news/route.ts",
  "app/api/workspace/news/translate/route.ts",
  "app/api/site-assistant/route.ts",
  "app/api/health/route.ts",
  "components/site/HomeNewsStrip.tsx",
  "components/site/NewsList.tsx",
  "app/globals.css",
  "CHANGELOG.md",
  "INSTALL.md",
  "VERSIONING.md"
)
foreach ($File in $Files) {
  $From = Join-Path $Source $File
  $To = Join-Path $Target $File
  $Dir = Split-Path -Parent $To
  if (-not (Test-Path $Dir)) { New-Item -ItemType Directory -Force -Path $Dir | Out-Null }
  Copy-Item -Force $From $To
  Write-Host "Installed $File"
}
Write-Host ""
Write-Host "Blue Whale V0.20 Platform Foundation installed."
Write-Host "IMPORTANT: restart npm run dev after environment-variable changes."
