import "server-only";
import { db } from "@/lib/database/server";

export const supabaseAdmin = db();
