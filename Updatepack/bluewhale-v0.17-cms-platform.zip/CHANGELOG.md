# Blue Whale V0.17 Changelog

## Release type

Odd version: backend, CMS, security and AI capability upgrade.

## CMS platform

- Rebuilt Company News CMS around a dedicated server-only Supabase admin client.
- Browser never receives `SUPABASE_SERVICE_ROLE_KEY`.
- `company_news` keeps RLS enabled.
- No public INSERT / UPDATE / DELETE policies are required.
- Added draft, published and archived states.
- Added CMS search and status filters.
- Added status counters.
- Added article preview in Chinese, Japanese and English.
- Added publish, unpublish-to-draft and archive actions.
- Added revision snapshots for create/update/delete recovery and audit support.
- Added duplicate-slug handling.

## AI-assisted content

- Added admin-only Chinese → Japanese translation draft.
- Added admin-only Chinese → English translation draft.
- AI output is treated as a draft and remains editable before publishing.
- Existing public AI Concierge remains read-only.

## Public website

- Preserves V0.16 visual design and global three-language system.
- Homepage news stream still reads only published news.
- `/news` and `/news/[slug]` remain public.
- Public news API now uses the dedicated server-only Supabase admin client.
- Added short CDN caching for public news list responses.

## Security

- Added constant-time comparison for `BLUEWHALE_ADMIN_KEY`.
- Service-role access is isolated in `lib/supabase-admin.ts`.
- CMS database writes happen only in Next.js server routes.
- RLS remains enabled on both news and revision tables.
- V0.17 does not require disabling RLS.

## Preserved

- Existing Sourcing OS.
- Existing internal Copilot.
- Existing inquiry submission flow.
- V0.16 company website and i18n.
