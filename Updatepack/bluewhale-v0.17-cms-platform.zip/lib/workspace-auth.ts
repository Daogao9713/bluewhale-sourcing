import "server-only";
import { timingSafeEqual } from "node:crypto";

function safeEqual(a: string, b: string) {
  const aa = Buffer.from(a);
  const bb = Buffer.from(b);
  return aa.length === bb.length && timingSafeEqual(aa, bb);
}

export function verifyWorkspaceKey(req: Request) {
  const configuredKey = process.env.BLUEWHALE_ADMIN_KEY;
  if (!configuredKey) {
    return { ok: false, status: 503, error: "Admin authentication is not configured." };
  }

  const providedKey = req.headers.get("x-admin-key") || "";
  if (!providedKey || !safeEqual(providedKey, configuredKey)) {
    return { ok: false, status: 401, error: "Unauthorized" };
  }

  return { ok: true, status: 200, error: "" };
}
