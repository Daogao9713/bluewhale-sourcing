import { NextResponse } from "next/server";
import { createSupabaseAdmin } from "@/lib/supabase-admin";

export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const rawLimit = Number(url.searchParams.get("limit") || "20");
    const limit = Math.min(Math.max(Number.isFinite(rawLimit) ? rawLimit : 20, 1), 50);

    const admin = createSupabaseAdmin();
    const { data, error } = await admin
      .from("company_news")
      .select(
        "id,slug,title_zh,title_ja,title_en,summary_zh,summary_ja,summary_en,cover_url,published_at,created_at"
      )
      .eq("status", "published")
      .not("published_at", "is", null)
      .lte("published_at", new Date().toISOString())
      .order("published_at", { ascending: false })
      .limit(limit);

    if (error) {
      console.error("[news:get]", error);
      return NextResponse.json({ success: false, error: "Failed to load news." }, { status: 500 });
    }

    return NextResponse.json(
      { success: true, news: data || [] },
      { headers: { "Cache-Control": "public, s-maxage=60, stale-while-revalidate=300" } }
    );
  } catch (error) {
    console.error("[news:get]", error);
    return NextResponse.json({ success: false, error: "Server error." }, { status: 500 });
  }
}
