import { NextResponse } from "next/server";
import { createSupabaseAdmin } from "@/lib/supabase-admin";
import { verifyWorkspaceKey } from "@/lib/workspace-auth";

const NEWS_FIELDS = `
  id,slug,title_zh,title_ja,title_en,
  summary_zh,summary_ja,summary_en,
  content_zh,content_ja,content_en,
  cover_url,status,published_at,created_at,updated_at
`;

function deny(req: Request) {
  const auth = verifyWorkspaceKey(req);
  return auth.ok
    ? null
    : NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
}

function text(value: unknown, max = 100000) {
  return String(value ?? "").trim().slice(0, max);
}

function slugify(value: unknown) {
  return text(value, 120)
    .toLowerCase()
    .replace(/[^a-z0-9\u4e00-\u9fff-]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function nullable(value: unknown, max?: number) {
  const valueText = text(value, max);
  return valueText || null;
}

function payload(body: any) {
  const status = ["draft", "published", "archived"].includes(body?.status)
    ? body.status
    : "draft";

  return {
    slug: slugify(body?.slug),
    title_zh: text(body?.title_zh, 240),
    title_ja: text(body?.title_ja, 240),
    title_en: text(body?.title_en, 240),
    summary_zh: nullable(body?.summary_zh, 1200),
    summary_ja: nullable(body?.summary_ja, 1200),
    summary_en: nullable(body?.summary_en, 1200),
    content_zh: nullable(body?.content_zh),
    content_ja: nullable(body?.content_ja),
    content_en: nullable(body?.content_en),
    cover_url: nullable(body?.cover_url, 2000),
    status,
    published_at:
      status === "published"
        ? body?.published_at || new Date().toISOString()
        : body?.published_at || null,
    updated_at: new Date().toISOString(),
  };
}

async function saveRevision(admin: ReturnType<typeof createSupabaseAdmin>, newsId: string, body: any) {
  const { error } = await admin.from("company_news_revisions").insert({
    news_id: newsId,
    snapshot: body,
  });
  if (error) console.warn("[cms:revision]", error.message);
}

export async function GET(req: Request) {
  const blocked = deny(req);
  if (blocked) return blocked;

  const url = new URL(req.url);
  const q = text(url.searchParams.get("q"), 100);
  const status = text(url.searchParams.get("status"), 20);

  const admin = createSupabaseAdmin();
  let query = admin
    .from("company_news")
    .select(NEWS_FIELDS)
    .order("updated_at", { ascending: false })
    .limit(200);

  if (status && ["draft", "published", "archived"].includes(status)) {
    query = query.eq("status", status);
  }

  if (q) {
    const safe = q.replace(/[%(),]/g, " ");
    query = query.or(
      `title_zh.ilike.%${safe}%,title_ja.ilike.%${safe}%,title_en.ilike.%${safe}%,slug.ilike.%${safe}%`
    );
  }

  const { data, error } = await query;
  if (error) {
    console.error("[cms:list]", error);
    return NextResponse.json({ success: false, error: "Failed to load news." }, { status: 500 });
  }

  return NextResponse.json({ success: true, news: data || [] });
}

export async function POST(req: Request) {
  const blocked = deny(req);
  if (blocked) return blocked;

  const body = await req.json();
  const item = payload(body);

  if (!item.slug || !item.title_zh) {
    return NextResponse.json(
      { success: false, error: "Slug and Chinese title are required." },
      { status: 400 }
    );
  }

  const admin = createSupabaseAdmin();
  const { data, error } = await admin
    .from("company_news")
    .insert(item)
    .select(NEWS_FIELDS)
    .single();

  if (error) {
    console.error("[cms:create]", error);
    return NextResponse.json(
      { success: false, error: error.code === "23505" ? "Slug already exists." : "Failed to create news." },
      { status: error.code === "23505" ? 409 : 500 }
    );
  }

  await saveRevision(admin, data.id, { event: "created", ...data });
  return NextResponse.json({ success: true, news: data });
}

export async function PATCH(req: Request) {
  const blocked = deny(req);
  if (blocked) return blocked;

  const body = await req.json();
  const id = text(body?.id, 80);
  if (!id) {
    return NextResponse.json({ success: false, error: "News id is required." }, { status: 400 });
  }

  const item = payload(body);
  if (!item.slug || !item.title_zh) {
    return NextResponse.json(
      { success: false, error: "Slug and Chinese title are required." },
      { status: 400 }
    );
  }

  const admin = createSupabaseAdmin();
  const { data: before } = await admin
    .from("company_news")
    .select(NEWS_FIELDS)
    .eq("id", id)
    .maybeSingle();

  const { data, error } = await admin
    .from("company_news")
    .update(item)
    .eq("id", id)
    .select(NEWS_FIELDS)
    .single();

  if (error) {
    console.error("[cms:update]", error);
    return NextResponse.json(
      { success: false, error: error.code === "23505" ? "Slug already exists." : "Failed to update news." },
      { status: error.code === "23505" ? 409 : 500 }
    );
  }

  if (before) await saveRevision(admin, id, { event: "updated", ...before });
  return NextResponse.json({ success: true, news: data });
}

export async function DELETE(req: Request) {
  const blocked = deny(req);
  if (blocked) return blocked;

  const id = text(new URL(req.url).searchParams.get("id"), 80);
  if (!id) {
    return NextResponse.json({ success: false, error: "News id is required." }, { status: 400 });
  }

  const admin = createSupabaseAdmin();
  const { data: before } = await admin
    .from("company_news")
    .select(NEWS_FIELDS)
    .eq("id", id)
    .maybeSingle();

  if (before) await saveRevision(admin, id, { event: "deleted", ...before });

  const { error } = await admin.from("company_news").delete().eq("id", id);
  if (error) {
    console.error("[cms:delete]", error);
    return NextResponse.json({ success: false, error: "Failed to delete news." }, { status: 500 });
  }

  return NextResponse.json({ success: true });
}
