import { NextResponse } from "next/server";
import { verifyWorkspaceKey } from "@/lib/workspace-auth";

function outputText(payload: any) {
  if (typeof payload?.output_text === "string") return payload.output_text;
  const chunks: string[] = [];
  for (const item of payload?.output || []) {
    for (const part of item?.content || []) {
      if (typeof part?.text === "string") chunks.push(part.text);
    }
  }
  return chunks.join("\n").trim();
}

export async function POST(req: Request) {
  const auth = verifyWorkspaceKey(req);
  if (!auth.ok) {
    return NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
  }

  const body = await req.json();
  const source = String(body?.source || "").trim().slice(0, 30000);
  const target = body?.target === "ja" ? "Japanese" : body?.target === "en" ? "English" : "";

  if (!source || !target) {
    return NextResponse.json({ success: false, error: "Source and target are required." }, { status: 400 });
  }

  const apiKey = process.env.OPENAI_API_KEY;
  const model = process.env.OPENAI_MODEL;
  if (!apiKey || !model) {
    return NextResponse.json({ success: false, error: "OpenAI is not configured." }, { status: 503 });
  }

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model,
      input: [
        {
          role: "system",
          content:
            `Translate corporate news from Chinese into ${target}. Preserve facts, names, numbers and paragraph structure. ` +
            `Use natural professional corporate language. Do not add claims, explanations or markdown fences. Return translation only.`,
        },
        { role: "user", content: source },
      ],
      max_output_tokens: 5000,
    }),
  });

  const payload = await response.json();
  if (!response.ok) {
    console.error("[cms:translate]", payload);
    return NextResponse.json({ success: false, error: "Translation failed." }, { status: 502 });
  }

  return NextResponse.json({ success: true, text: outputText(payload) });
}
