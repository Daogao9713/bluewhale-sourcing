# Blue Whale V0.17 CMS Platform Upgrade

V0.17 is intended to be installed on top of V0.16.

## 1. Create a branch

```bash
git checkout -b backend/v0.17-cms-platform
```

## 2. Install

Windows:

```powershell
.\install.ps1 "C:\path\to\bluewhale-sourcing"
```

macOS / Linux:

```bash
chmod +x install.sh
./install.sh /path/to/bluewhale-sourcing
```

## 3. Environment variables

Required:

```env
NEXT_PUBLIC_SUPABASE_URL=
SUPABASE_SERVICE_ROLE_KEY=
BLUEWHALE_ADMIN_KEY=
OPENAI_API_KEY=
OPENAI_MODEL=
```

### Critical check

`SUPABASE_SERVICE_ROLE_KEY` must be the Supabase **service role / secret server key**.

Do not put it in:

- `NEXT_PUBLIC_*`
- browser code
- GitHub
- screenshots
- public logs

After changing Vercel environment variables, redeploy the application.

## 4. Database migration

Run this file in the Supabase SQL Editor:

`supabase/bluewhale_v017_cms.sql`

This migration:

- keeps RLS enabled;
- adds `archived` news state;
- adds revision history;
- creates indexes;
- does not create public write policies.

You do **not** need to disable RLS.

## 5. Build

```bash
npm install
npm run build
```

No new npm package is required if `@supabase/supabase-js` already exists in the project.

## 6. CMS test

Open:

`/workspace/news`

Enter the existing `BLUEWHALE_ADMIN_KEY`.

Create a draft with:

- slug
- Chinese title
- Chinese summary
- Chinese body

Save it.

Then test:

1. AI → Japanese
2. AI → English
3. review the translations
4. use the ZH / JA / EN preview
5. click Publish
6. open `/news`
7. open the article detail page
8. switch the public website language

## 7. RLS verification

If V0.17 is wired correctly, the CMS can publish while RLS remains enabled.

If you still see:

`new row violates row-level security policy`

do **not** disable RLS.

Check:

1. Vercel has `SUPABASE_SERVICE_ROLE_KEY`;
2. the key belongs to the same Supabase project as `NEXT_PUBLIC_SUPABASE_URL`;
3. Vercel was redeployed after setting the variable;
4. `lib/supabase-admin.ts` is installed;
5. `/api/workspace/news` imports `createSupabaseAdmin`.

## 8. Expected architecture

```text
Browser
  |
  | x-admin-key
  v
Next.js /api/workspace/news
  |
  | server-only service role
  v
Supabase
  |
  +-- RLS stays enabled
```

The service-role credential never crosses into the browser.

## 9. AI translation

AI translation requires:

```env
OPENAI_API_KEY=
OPENAI_MODEL=
```

The CMS translation button is admin-only and returns an editable draft.

If AI is not configured, normal CMS publishing still works.
