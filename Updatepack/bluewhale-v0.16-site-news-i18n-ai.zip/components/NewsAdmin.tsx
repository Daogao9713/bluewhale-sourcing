"use client";

import Link from "next/link";
import { FormEvent, useEffect, useState } from "react";

type News = {
  id: string;
  slug: string;
  title_zh: string;
  title_ja: string;
  title_en: string;
  summary_zh?: string | null;
  summary_ja?: string | null;
  summary_en?: string | null;
  content_zh?: string | null;
  content_ja?: string | null;
  content_en?: string | null;
  cover_url?: string | null;
  status: "draft" | "published";
  published_at?: string | null;
};

const empty = {
  id: "",
  slug: "",
  title_zh: "",
  title_ja: "",
  title_en: "",
  summary_zh: "",
  summary_ja: "",
  summary_en: "",
  content_zh: "",
  content_ja: "",
  content_en: "",
  cover_url: "",
  status: "draft" as const,
  published_at: "",
};

export default function NewsAdmin() {
  const [key, setKey] = useState("");
  const [draftKey, setDraftKey] = useState("");
  const [items, setItems] = useState<News[]>([]);
  const [form, setForm] = useState<any>(empty);
  const [loading, setLoading] = useState(false);
  const [notice, setNotice] = useState("");

  useEffect(() => {
    const stored = window.sessionStorage.getItem("bluewhale_admin_key") || "";
    if (stored) setKey(stored);
  }, []);

  useEffect(() => {
    if (key) load();
  }, [key]);

  async function load() {
    setLoading(true);
    setNotice("");
    try {
      const res = await fetch("/api/workspace/news", {
        headers: { "x-admin-key": key },
        cache: "no-store",
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || "Load failed");
      setItems(data.news || []);
    } catch (e) {
      setNotice(e instanceof Error ? e.message : "Load failed");
    } finally {
      setLoading(false);
    }
  }

  function unlock(e: FormEvent) {
    e.preventDefault();
    const value = draftKey.trim();
    if (!value) return;
    window.sessionStorage.setItem("bluewhale_admin_key", value);
    setKey(value);
  }

  function edit(item: News) {
    setForm({
      ...empty,
      ...item,
      published_at: item.published_at ? item.published_at.slice(0, 16) : "",
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function save(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setNotice("");

    try {
      const res = await fetch("/api/workspace/news", {
        method: form.id ? "PATCH" : "POST",
        headers: {
          "Content-Type": "application/json",
          "x-admin-key": key,
        },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || "Save failed");
      setNotice(form.id ? "News updated." : "News created.");
      setForm(empty);
      await load();
    } catch (e) {
      setNotice(e instanceof Error ? e.message : "Save failed");
    } finally {
      setLoading(false);
    }
  }

  async function remove(id: string) {
    if (!window.confirm("Delete this news item?")) return;
    const res = await fetch(`/api/workspace/news?id=${encodeURIComponent(id)}`, {
      method: "DELETE",
      headers: { "x-admin-key": key },
    });
    const data = await res.json();
    if (!res.ok) {
      setNotice(data?.error || "Delete failed");
      return;
    }
    if (form.id === id) setForm(empty);
    await load();
  }

  const set = (name: string, value: string) =>
    setForm((old: any) => ({ ...old, [name]: value }));

  if (!key) {
    return (
      <main className="min-h-screen bg-slate-50 px-6 py-16">
        <div className="mx-auto max-w-md rounded-[2rem] border border-slate-200 bg-white p-8 shadow-xl">
          <p className="text-xs font-semibold tracking-[0.18em] text-cyan-700">BLUE WHALE CMS</p>
          <h1 className="mt-4 text-3xl font-semibold">Company News</h1>
          <form onSubmit={unlock} className="mt-8">
            <input
              type="password"
              value={draftKey}
              onChange={(e) => setDraftKey(e.target.value)}
              placeholder="Workspace admin key"
              className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-cyan-600"
            />
            <button className="mt-3 w-full rounded-2xl bg-slate-950 px-4 py-3 font-semibold text-white">
              Unlock
            </button>
          </form>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-slate-50">
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-[1500px] items-center justify-between px-6 py-5">
          <div>
            <p className="text-xs font-semibold tracking-[0.18em] text-cyan-700">BLUE WHALE CMS · V0.16</p>
            <h1 className="mt-1 text-xl font-semibold">Company News Manager</h1>
          </div>
          <div className="flex gap-2">
            <Link href="/news" className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm">Public news</Link>
            <Link href="/workspace" className="rounded-full bg-slate-950 px-4 py-2 text-sm text-white">Workspace</Link>
          </div>
        </div>
      </header>

      <div className="mx-auto grid max-w-[1500px] gap-6 px-6 py-8 xl:grid-cols-[620px_minmax(0,1fr)]">
        <form onSubmit={save} className="h-fit rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-semibold">{form.id ? "Edit news" : "New news"}</h2>
              <p className="mt-1 text-xs text-slate-500">Store all three languages in one record.</p>
            </div>
            {form.id ? (
              <button type="button" onClick={() => setForm(empty)} className="text-xs font-semibold text-slate-500">
                New
              </button>
            ) : null}
          </div>

          <div className="mt-6 space-y-4">
            <input required value={form.slug} onChange={(e) => set("slug", e.target.value)} placeholder="slug, e.g. company-launch-2026" className="field" />
            <input required value={form.title_zh} onChange={(e) => set("title_zh", e.target.value)} placeholder="中文标题 *" className="field" />
            <input value={form.title_ja} onChange={(e) => set("title_ja", e.target.value)} placeholder="日本語タイトル" className="field" />
            <input value={form.title_en} onChange={(e) => set("title_en", e.target.value)} placeholder="English title" className="field" />

            <textarea value={form.summary_zh} onChange={(e) => set("summary_zh", e.target.value)} rows={2} placeholder="中文摘要" className="field" />
            <textarea value={form.summary_ja} onChange={(e) => set("summary_ja", e.target.value)} rows={2} placeholder="日本語要約" className="field" />
            <textarea value={form.summary_en} onChange={(e) => set("summary_en", e.target.value)} rows={2} placeholder="English summary" className="field" />

            <textarea value={form.content_zh} onChange={(e) => set("content_zh", e.target.value)} rows={7} placeholder="中文正文" className="field" />
            <textarea value={form.content_ja} onChange={(e) => set("content_ja", e.target.value)} rows={7} placeholder="日本語本文" className="field" />
            <textarea value={form.content_en} onChange={(e) => set("content_en", e.target.value)} rows={7} placeholder="English body" className="field" />

            <input value={form.cover_url} onChange={(e) => set("cover_url", e.target.value)} placeholder="Cover image URL (optional)" className="field" />

            <div className="grid grid-cols-2 gap-3">
              <select value={form.status} onChange={(e) => set("status", e.target.value)} className="field">
                <option value="draft">Draft</option>
                <option value="published">Published</option>
              </select>
              <input type="datetime-local" value={form.published_at} onChange={(e) => set("published_at", e.target.value)} className="field" />
            </div>
          </div>

          {notice ? <p className="mt-4 text-sm text-cyan-700">{notice}</p> : null}

          <button disabled={loading} className="mt-5 w-full rounded-2xl bg-slate-950 px-4 py-3 font-semibold text-white disabled:opacity-50">
            {loading ? "Saving..." : form.id ? "Update news" : "Create news"}
          </button>
        </form>

        <section>
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="text-xl font-semibold">News library</h2>
              <p className="mt-1 text-xs text-slate-500">{items.length} records</p>
            </div>
            <button onClick={load} className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm">Refresh</button>
          </div>

          <div className="space-y-3">
            {items.map((item) => (
              <article key={item.id} className="rounded-[1.6rem] border border-slate-200 bg-white p-5 shadow-sm">
                <div className="flex flex-col justify-between gap-4 md:flex-row">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className={`rounded-full px-2.5 py-1 text-[10px] font-semibold ${item.status === "published" ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>
                        {item.status}
                      </span>
                      <span className="truncate text-xs text-slate-400">{item.slug}</span>
                    </div>
                    <h3 className="mt-3 text-lg font-semibold">{item.title_zh}</h3>
                    <p className="mt-1 text-xs text-slate-500">{item.title_ja || "—"}</p>
                    <p className="mt-1 text-xs text-slate-500">{item.title_en || "—"}</p>
                  </div>
                  <div className="flex shrink-0 gap-2">
                    <button onClick={() => edit(item)} className="rounded-full border border-slate-200 px-4 py-2 text-xs font-semibold">Edit</button>
                    <button onClick={() => remove(item.id)} className="rounded-full border border-rose-200 px-4 py-2 text-xs font-semibold text-rose-600">Delete</button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}
