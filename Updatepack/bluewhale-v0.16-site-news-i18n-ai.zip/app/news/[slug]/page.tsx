import { notFound } from "next/navigation";
import CompanySiteLayout from "@/components/site/CompanySiteLayout";
import NewsArticle from "@/components/site/NewsArticle";
import { supabaseAdmin } from "@/lib/supabase";

export default async function NewsDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;

  const { data, error } = await supabaseAdmin
    .from("company_news")
    .select("*")
    .eq("slug", slug)
    .eq("status", "published")
    .lte("published_at", new Date().toISOString())
    .single();

  if (error || !data) notFound();

  return (
    <CompanySiteLayout>
      <NewsArticle article={data} />
    </CompanySiteLayout>
  );
}
