import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase";
import { verifyWorkspaceKey } from "@/lib/workspace-auth";

function blocked(req: Request) {
  const auth = verifyWorkspaceKey(req);
  return auth.ok
    ? null
    : NextResponse.json({ success: false, error: auth.error }, { status: auth.status });
}

function cleanSlug(value: unknown) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9\u4e00-\u9fff-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 120);
}

function newsPayload(body: any) {
  return {
    slug: cleanSlug(body.slug),
    title_zh: String(body.title_zh || "").trim(),
    title_ja: String(body.title_ja || "").trim(),
    title_en: String(body.title_en || "").trim(),
    summary_zh: String(body.summary_zh || "").trim() || null,
    summary_ja: String(body.summary_ja || "").trim() || null,
    summary_en: String(body.summary_en || "").trim() || null,
    content_zh: String(body.content_zh || "").trim() || null,
    content_ja: String(body.content_ja || "").trim() || null,
    content_en: String(body.content_en || "").trim() || null,
    cover_url: String(body.cover_url || "").trim() || null,
    status: ["draft", "published"].includes(body.status) ? body.status : "draft",
    published_at:
      body.status === "published"
        ? body.published_at || new Date().toISOString()
        : body.published_at || null,
    updated_at: new Date().toISOString(),
  };
}

export async function GET(req: Request) {
  const deny = blocked(req);
  if (deny) return deny;

  const { data, error } = await supabaseAdmin
    .from("company_news")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(100);

  if (error) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }

  return NextResponse.json({ success: true, news: data || [] });
}

export async function POST(req: Request) {
  const deny = blocked(req);
  if (deny) return deny;

  const body = await req.json();
  const payload = newsPayload(body);

  if (!payload.slug || !payload.title_zh) {
    return NextResponse.json(
      { success: false, error: "slug and Chinese title are required." },
      { status: 400 }
    );
  }

  const { data, error } = await supabaseAdmin
    .from("company_news")
    .insert(payload)
    .select()
    .single();

  if (error) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }

  return NextResponse.json({ success: true, news: data });
}

export async function PATCH(req: Request) {
  const deny = blocked(req);
  if (deny) return deny;

  const body = await req.json();
  const id = String(body.id || "");
  if (!id) {
    return NextResponse.json({ success: false, error: "id is required." }, { status: 400 });
  }

  const payload = newsPayload(body);
  if (!payload.slug || !payload.title_zh) {
    return NextResponse.json(
      { success: false, error: "slug and Chinese title are required." },
      { status: 400 }
    );
  }

  const { data, error } = await supabaseAdmin
    .from("company_news")
    .update(payload)
    .eq("id", id)
    .select()
    .single();

  if (error) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }

  return NextResponse.json({ success: true, news: data });
}

export async function DELETE(req: Request) {
  const deny = blocked(req);
  if (deny) return deny;

  const url = new URL(req.url);
  const id = url.searchParams.get("id");
  if (!id) {
    return NextResponse.json({ success: false, error: "id is required." }, { status: 400 });
  }

  const { error } = await supabaseAdmin.from("company_news").delete().eq("id", id);
  if (error) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }

  return NextResponse.json({ success: true });
}
