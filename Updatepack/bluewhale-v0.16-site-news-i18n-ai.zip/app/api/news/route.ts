import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase";

export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const rawLimit = Number(url.searchParams.get("limit") || "20");
    const limit = Math.min(Math.max(rawLimit, 1), 50);

    const { data, error } = await supabaseAdmin
      .from("company_news")
      .select(
        "id,slug,title_zh,title_ja,title_en,summary_zh,summary_ja,summary_en,cover_url,published_at,created_at"
      )
      .eq("status", "published")
      .lte("published_at", new Date().toISOString())
      .order("published_at", { ascending: false })
      .limit(limit);

    if (error) {
      console.error("[news:get]", error);
      return NextResponse.json({ success: false, error: "Failed to load news." }, { status: 500 });
    }

    return NextResponse.json({ success: true, news: data || [] });
  } catch (error) {
    console.error("[news:get]", error);
    return NextResponse.json({ success: false, error: "Server error." }, { status: 500 });
  }
}
