#!/usr/bin/env bash
set -euo pipefail

TARGET="${1:-}"

if [[ -z "$TARGET" ]]; then
  echo "Usage: ./install.sh /path/to/bluewhale-sourcing"
  exit 1
fi

if [[ ! -d "$TARGET" ]]; then
  echo "Target directory does not exist: $TARGET"
  exit 1
fi

SOURCE="$(cd "$(dirname "$0")" && pwd)"

FILES=(
  "app/layout.tsx"
  "app/globals.css"
  "app/about/page.tsx"
  "app/business/page.tsx"
  "app/business/sourcing/page.tsx"
  "app/technology/page.tsx"
  "app/contact/page.tsx"
  "app/inquiry/page.tsx"
  "app/news/page.tsx"
  "app/news/[slug]/page.tsx"
  "app/workspace/news/page.tsx"
  "app/api/news/route.ts"
  "app/api/workspace/news/route.ts"
  "app/api/site-assistant/route.ts"
  "components/HomeContent.tsx"
  "components/InquiryForm.tsx"
  "components/NewsAdmin.tsx"
  "components/site/CompanySiteLayout.tsx"
  "components/site/SiteHeader.tsx"
  "components/site/SiteFooter.tsx"
  "components/site/SiteLanguageProvider.tsx"
  "components/site/LanguageSwitcher.tsx"
  "components/site/HomeNewsStrip.tsx"
  "components/site/SiteAssistant.tsx"
  "components/site/StaticPages.tsx"
  "components/site/NewsList.tsx"
  "components/site/NewsIndexContent.tsx"
  "components/site/NewsArticle.tsx"
  "lib/site-i18n.ts"
  "lib/workspace-auth.ts"
  "supabase/bluewhale_v016_news.sql"
  "VERSIONING.md"
  "CHANGELOG.md"
  "INSTALL.md"
  "WORKSPACE_NEWS_LINK.patch.md"
)

for file in "${FILES[@]}"; do
  mkdir -p "$(dirname "$TARGET/$file")"
  cp "$SOURCE/$file" "$TARGET/$file"
  echo "Installed $file"
done

echo
echo "Blue Whale V0.16 installed."
echo "Next: run supabase/bluewhale_v016_news.sql, then npm run build."
