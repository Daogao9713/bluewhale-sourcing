param(
  [Parameter(Mandatory=$true)]
  [string]$Target
)

$ErrorActionPreference = "Stop"

if (-not (Test-Path $Target)) {
  throw "Target directory does not exist: $Target"
}

$Source = Split-Path -Parent $MyInvocation.MyCommand.Path

$Files = @(
  "app/layout.tsx",
  "app/globals.css",
  "app/about/page.tsx",
  "app/business/page.tsx",
  "app/business/sourcing/page.tsx",
  "app/technology/page.tsx",
  "app/contact/page.tsx",
  "app/inquiry/page.tsx",
  "app/news/page.tsx",
  "app/news/[slug]/page.tsx",
  "app/workspace/news/page.tsx",
  "app/api/news/route.ts",
  "app/api/workspace/news/route.ts",
  "app/api/site-assistant/route.ts",
  "components/HomeContent.tsx",
  "components/InquiryForm.tsx",
  "components/NewsAdmin.tsx",
  "components/site/CompanySiteLayout.tsx",
  "components/site/SiteHeader.tsx",
  "components/site/SiteFooter.tsx",
  "components/site/SiteLanguageProvider.tsx",
  "components/site/LanguageSwitcher.tsx",
  "components/site/HomeNewsStrip.tsx",
  "components/site/SiteAssistant.tsx",
  "components/site/StaticPages.tsx",
  "components/site/NewsList.tsx",
  "components/site/NewsIndexContent.tsx",
  "components/site/NewsArticle.tsx",
  "lib/site-i18n.ts",
  "lib/workspace-auth.ts",
  "supabase/bluewhale_v016_news.sql",
  "VERSIONING.md",
  "CHANGELOG.md",
  "INSTALL.md",
  "WORKSPACE_NEWS_LINK.patch.md"
)

foreach ($File in $Files) {
  $From = Join-Path $Source $File
  $To = Join-Path $Target $File
  $Dir = Split-Path -Parent $To

  if (-not (Test-Path $Dir)) {
    New-Item -ItemType Directory -Force -Path $Dir | Out-Null
  }

  Copy-Item -Force $From $To
  Write-Host "Installed $File"
}

Write-Host ""
Write-Host "Blue Whale V0.16 installed."
Write-Host "Next: run supabase/bluewhale_v016_news.sql, then npm run build."
