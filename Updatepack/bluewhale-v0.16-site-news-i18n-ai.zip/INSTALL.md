# Blue Whale V0.16 Upgrade

V0.16 is designed to install after V0.12 and the earlier Sourcing OS package.

## 1. Recommended branch

```bash
git checkout -b frontend/v0.16-news-i18n-ai
```

## 2. Install package

Windows:

```powershell
.\install.ps1 "C:\path\to\bluewhale-sourcing"
```

macOS / Linux:

```bash
chmod +x install.sh
./install.sh /path/to/bluewhale-sourcing
```

## 3. Run Supabase migration

In Supabase SQL Editor run:

`supabase/bluewhale_v016_news.sql`

This creates `company_news`.

## 4. Environment variables

Existing variables remain required:

```env
NEXT_PUBLIC_SUPABASE_URL=
SUPABASE_SERVICE_ROLE_KEY=
BLUEWHALE_ADMIN_KEY=
OPENAI_API_KEY=
OPENAI_MODEL=
```

V0.16 intentionally does not hard-code an OpenAI model name.
Use the same tested `OPENAI_MODEL` you configure for the project.

## 5. Build

No new npm packages are required.

```bash
npm install
npm run build
npm run dev
```

## 6. Test order

### Public language system

Open `/`.

Switch:

- 中文
- 日本語
- EN

Then visit:

- `/about`
- `/business`
- `/business/sourcing`
- `/technology`
- `/news`
- `/contact`
- `/inquiry`

The selected language should persist across pages and refreshes.

### News CMS

Open:

`/workspace/news`

Use the same `BLUEWHALE_ADMIN_KEY` as `/workspace`.

Create one item with:

- slug
- Chinese title
- Japanese title
- English title
- summaries
- bodies
- status = Published

Then confirm:

1. it appears in `/news`;
2. it appears in the homepage horizontal news stream;
3. `/news/<slug>` opens;
4. switching languages changes the article text.

### AI Concierge

Open any public page and click the floating AI button.

Try:

Chinese:
`蓝鲸新能源有哪些业务？最近有什么公司新闻？`

Japanese:
`ブルーホエールの事業内容と最新ニュースを教えて。`

English:
`What does Blue Whale do, and where should I submit a sourcing request?`

The assistant should:

- answer in the selected website language;
- use only published company context;
- point to pages such as `/business`, `/news`, `/business/sourcing`, `/inquiry`;
- never claim it can modify internal Sourcing OS data.

## 7. Important

The news CMS supports plain-text article bodies in V0.16.

Do not paste raw HTML into the content fields.

A later even release can add a rich-text editor and media upload.

## 8. Workspace shortcut

The CMS works at `/workspace/news` without modifying the existing large `WorkspaceShell`.

See `WORKSPACE_NEWS_LINK.patch.md` if you want to add a sidebar shortcut manually.
