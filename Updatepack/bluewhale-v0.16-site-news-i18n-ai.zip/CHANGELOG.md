# Blue Whale V0.16 Changelog

## Release type

Even version: Frontend-led mixed upgrade.

## New

- Whole-site Chinese / Japanese / English language system.
- Language selection persists in browser localStorage.
- Header, footer, all major public pages and the inquiry form share one language state.
- New company news database model.
- Homepage horizontal company news stream.
- `/news` company news index.
- `/news/[slug]` news detail pages.
- `/workspace/news` company news CMS.
- Draft / publish workflow for news.
- Three-language fields for each news item.
- Optional cover image URL.
- Public Blue Whale AI Concierge floating panel.
- AI Concierge reads current published news before answering.
- AI Concierge guides visitors to public pages and inquiry flow.
- Public AI and internal Sourcing OS Copilot remain separate roles.

## Preserved

- Existing `/workspace` Sourcing OS.
- Existing `/api/workspace`.
- Existing internal AI Copilot.
- Existing `/api/inquiry`.
- Existing Supabase / Resend inquiry flow.

## Important design decision

News is stored natively in Chinese, Japanese and English rather than translated on every page request.

This makes public content stable, editable and auditable.

The public AI Concierge is read-only and cannot modify projects, suppliers, RFQs or news.
