# Optional Workspace Link Patch

V0.16 adds the news CMS at:

`/workspace/news`

It is intentionally a standalone workspace sub-page so this package does not overwrite your large existing `components/WorkspaceShell.tsx`.

If you want a visible shortcut inside the existing Sourcing OS sidebar, add:

```tsx
<Link href="/workspace/news">Company News</Link>
```

to the workspace navigation area.

This is optional. The CMS works directly at `/workspace/news`.
